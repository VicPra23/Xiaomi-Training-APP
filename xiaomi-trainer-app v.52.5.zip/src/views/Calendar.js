function renderCalendar(container) {
    window.disposeCalendar?.();
    let disposed = false, loadSequence = 0, transferBusy = false, isDragging = false;
    const active = () => !disposed && container.isConnected && location.hash === '#calendar';
    let refreshTimer;
    window.disposeCalendar = () => { disposed = true; clearInterval(refreshTimer); monthObserver?.disconnect(); document.querySelectorAll('.calendar-editor-overlay,.calendar-clipboard-overlay,dialog.calendar-delete-dialog').forEach(el=>el.remove()); document.body.classList.remove('calendar-editor-open'); };
    const revision = (date,user) => calendarData?.versions?.[date]?.[user];
    const ensureConnected = () => {
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
            throw new Error('Sin conexión a Internet. Comprueba tu red antes de guardar.');
        }
    };
    const saveDay = async (request) => {
        ensureConnected();
        const response = await api.saveCalendarAssignment({
            ...request,
            expectedVersion: request.expectedVersion || revision(request.date, request.user) || ''
        });
        if (response.status !== 'success') {
            throw new Error(response.message || 'Error al guardar la planificación.');
        }
        return response;
    };
    const MONTHS = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    const DAYS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
    const categories = [
        { id: "eci", label: "ECI", color: "#00c853" },
        { id: "mm", label: "MM", color: "#d0021b" },
        { id: "crf", label: "CRF", color: "#2196f3" },
        { id: "mistores", label: "Mi Stores", color: "#ffb800" },
        { id: "osp", label: "OSP", color: "#ff6700" },
        { id: "vdf", label: "VDF", color: "#f44336" },
        { id: "mmy", label: "MMY", color: "#9c27b0" },
        { id: "tme", label: "TME", color: "#00bcd4" },
        { id: "interno", label: "Interno", color: "#ffeb3b" },
        { id: "materiales", label: "Materiales", color: "#795548" },
        { id: "tentativa", label: "Tentativa", color: "#e2e8f0" },
        { id: "otros", label: "Otros", color: "#607d8b" }
    ];

    const now = new Date();
    const session = getSessionData();
    const currentUser = session ? session.user : "";
    const isAdmin = Boolean(session && session.role === "Admin");
    let selectedYear = now.getFullYear();
    let calendarData = null;
    let suggestionCatalog = [];
    let hideWeekends = false;
    let monthObserver = null;
    const CALENDAR_START_YEAR = 2026;

    const createLocalDate = (year, month, day) => new Date(year, month, day, 0, 0, 0, 0);
    const toISO = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    const todayISO = toISO(now);
    const deepCopyItems = (items) => {
        if (!items) return [];
        if (!Array.isArray(items)) {
            return [{ text: String(items.text || ""), category: items.category || "otros" }];
        }
        return items.map(item => ({ text: String(item?.text || ""), category: item?.category || "otros" }));
    };
    const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[char]));

    container.innerHTML = `
        <section class="calendar-module continuous-calendar fade-in" aria-labelledby="calendar-title">
            <header class="calendar-command-bar">
                <div class="calendar-title-group">
                    <span class="calendar-eyebrow">Planificación anual</span>
                    <h2 id="calendar-title">Calendario <strong id="calendarActiveMonth">${MONTHS[now.getMonth()]}</strong></h2>
                    <p>Desplázate para recorrer el año. Pulsa un día para planificarlo.</p>
                </div>
                <div class="calendar-primary-actions">
                    <button id="calendarSyncBtn" class="btn-secondary calendar-sync-btn" type="button" aria-label="Sincronizar ahora con Google Sheets" title="Sincronizar ahora con Google Sheets">
                        <i data-lucide="refresh-cw"></i><span>Sincronizar</span>
                    </button>
                    <button id="calendarPhoneSyncBtn" class="btn-secondary calendar-phone-sync-btn" type="button" aria-label="Sincronizar calendario con el móvil y avisos" title="Sincronizar con el móvil y avisos">
                        <i data-lucide="bell-ring"></i><span>Móvil y Avisos</span>
                    </button>
                    <button id="calendarToday" class="btn-primary calendar-today-btn" type="button" aria-label="Ir al día de hoy">
                        <i data-lucide="locate-fixed"></i><span>Hoy</span>
                    </button>
                    <label class="calendar-year-control">
                        <span>Año</span>
                        <select id="calendarYear" aria-label="Seleccionar año">
                            ${Array.from({ length: Math.max(1, now.getFullYear() + 2 - CALENDAR_START_YEAR + 1) }, (_, index) => CALENDAR_START_YEAR + index)
                                .map(year => `<option value="${year}" ${year === selectedYear ? "selected" : ""}>${year}</option>`).join("")}
                        </select>
                    </label>
                </div>
            </header>

            <div class="calendar-tool-row">
                <label class="calendar-year-control" id="calendarTrainerWrapper" style="display: none; margin-right: auto; min-width: 250px;">
                    <span>Formadores</span>
                    <select id="calendarTrainerFilter" multiple aria-label="Seleccionar formadores"></select>
                </label>
                <label class="calendar-weekend-toggle">
                    <input id="calendarWeekendToggle" type="checkbox">
                    <span>Ocultar fin de semana</span>
                </label>
                <button id="calendarClipboardStatus" type="button" class="calendar-clipboard-status" aria-live="polite">
                    <i data-lucide="clipboard"></i><span>Portapapeles vacío</span>
                </button>
            </div>

            <details class="calendar-legend" open>
                <summary><i data-lucide="palette"></i><span>Leyenda de actividades</span></summary>
                <div class="calendar-legend-grid">
                    ${categories.map(category => `
                        <div class="calendar-legend-item"><span class="calendar-legend-swatch cat-${category.id}"></span><strong>${category.label}</strong></div>
                    `).join("")}
                    
                    
                </div>
            </details>

            <nav id="calendarMonthRail" class="calendar-month-rail" aria-label="Ir a un mes">
                ${MONTHS.map((month, index) => `
                    <button type="button" data-month="${index}" class="${index === now.getMonth() ? "is-active" : ""}">
                        <span>${String(index + 1).padStart(2, "0")}</span>${month.slice(0, 3)}
                    </button>
                `).join("")}
            </nav>

            <div id="calendarLoading" class="calendar-loading" role="status">
                <div class="calendar-loader-mark"></div>
                <div><strong>Preparando el año</strong><span>Sincronizando planificación y ausencias…</span></div>
            </div>
            <div id="calendarYearScroll" class="calendar-year-scroll" tabindex="0" aria-label="Calendario anual con desplazamiento">
                <div id="calendarMonths" class="calendar-months"></div>
            </div>
            <div id="calendarLiveRegion" class="sr-only" aria-live="polite"></div>
        </section>
    `;

    const yearScroll = container.querySelector("#calendarYearScroll");
    const monthRail = container.querySelector("#calendarMonthRail");
    const loading = container.querySelector("#calendarLoading");

    if (typeof lucide !== "undefined") lucide.createIcons();
    updateClipboardStatus();
    loadYear(selectedYear, now.getMonth());
    refreshTimer = setInterval(() => {
        if (active() && !document.hidden && !document.querySelector('.calendar-editor-overlay,.calendar-clipboard-overlay,dialog[open]') && !transferBusy && !isDragging) {
            loadYear(selectedYear, now.getMonth(), true, true);
        }
    }, 60000);

    container.querySelector("#calendarYear").addEventListener("change", event => {
        selectedYear = Number(event.target.value);
        loadYear(selectedYear, selectedYear === now.getFullYear() ? now.getMonth() : 0);
    });

    container.querySelector("#calendarSyncBtn")?.addEventListener("click", async () => {
        const syncBtn = container.querySelector("#calendarSyncBtn");
        const icon = syncBtn?.querySelector("i");
        if (syncBtn) syncBtn.disabled = true;
        if (icon) icon.classList.add("spin-anim");
        try {
            await loadYear(selectedYear, now.getMonth(), true, false);
            announce("Calendario sincronizado con Google Sheets con éxito.");
        } catch(err) {
            announce(err.message || "Error al sincronizar con Google Sheets.", true);
        } finally {
            if (syncBtn) syncBtn.disabled = false;
            if (icon) icon.classList.remove("spin-anim");
            if (typeof lucide !== "undefined") lucide.createIcons();
        }
    });

    container.querySelector("#calendarPhoneSyncBtn")?.addEventListener("click", () => {
        showPhoneSyncDialog();
    });

    container.querySelector("#calendarToday").addEventListener("click", async () => {
        if (selectedYear !== now.getFullYear()) {
            selectedYear = now.getFullYear();
            container.querySelector("#calendarYear").value = selectedYear;
            await loadYear(selectedYear, now.getMonth());
        } else {
            scrollToToday(true);
        }
    });

    monthRail.addEventListener("click", event => {
        const button = event.target.closest("[data-month]");
        if (button) scrollToMonth(Number(button.dataset.month), true);
    });

    container.querySelector("#calendarWeekendToggle").addEventListener("change", event => {
        hideWeekends = event.target.checked;
        container.classList.toggle("calendar-hide-weekends", hideWeekends);
    });
    container.querySelector("#calendarClipboardStatus").addEventListener("click", async () => {
        const entries = getClipboards();
        if (entries.length) await chooseClipboard(entries, "Portapapeles", "Selecciona una copia para ver su contenido");
    });

    async function loadYear(year, focusMonth = 0, preserveScroll = false, silent = false) {
        const sequence = ++loadSequence;
        const current = () => active() && sequence === loadSequence && year === selectedYear;
        const isBackground = silent || Boolean(calendarData);
        if (!isBackground) {
            loading.hidden = false;
            yearScroll.classList.add('is-loading');
        }
        try {
            const [usersRes,scheduleRes] = await Promise.all([api.getUsersList(),api.getWeekly({start:year+'-01-01',end:year+'-12-31',refresh:preserveScroll})]);
            if (!current()) return;
            if (usersRes.status !== 'success' || scheduleRes.status !== 'success') throw new Error(usersRes.message || scheduleRes.message || 'No se pudo cargar el calendario.');
            const wasConnected = Boolean(calendarData && !calendarData.offline);
            
            // Garantizar que todos los formadores activos de la intranet (incluyendo Francisco Javier / TL) estén en la lista
            const appTrainers = (usersRes.data || []).filter(u => {
                const uid = typeof u === 'object' ? u.user : u;
                return uid !== 'Training Manager' && uid !== 'Training Coordinator' && uid !== 'Training Creator';
            });
            const scheduleUsers = scheduleRes.users || [];
            const mergedUsers = [...scheduleUsers];
            appTrainers.forEach(trainer => {
                const tUid = typeof trainer === 'object' ? trainer.user : trainer;
                const tName = typeof trainer === 'object' ? trainer.name : trainer;
                const exists = mergedUsers.some(u => {
                    const uid = typeof u === 'object' ? u.user : u;
                    const name = typeof u === 'object' ? u.name : u;
                    return uid === tUid || name === tName || (tUid === 'TL' && (uid === 'TL' || name === 'Francisco Javier'));
                });
                if (!exists) {
                    mergedUsers.push(trainer);
                }
            });

            calendarData = {
                users: mergedUsers.length ? mergedUsers : appTrainers,
                schedule: scheduleRes.schedule || {},
                blocks: scheduleRes.blocks || {},
                source: scheduleRes.source,
                versions: scheduleRes.versions || {},
                capacities: scheduleRes.capacities || {},
                offline: Boolean(scheduleRes.offline && !wasConnected)
            };
            if (isAdmin) {
                const wrapper=container.querySelector('#calendarTrainerWrapper'),select=container.querySelector('#calendarTrainerFilter');
                if (select && !select.tomselect) {
                    wrapper.style.display='flex';
                    select.innerHTML=calendarData.users.filter(u=>(u.user || u)!=='Training Manager').map(u=>`<option value="${escapeHTML(u.user || u)}">${escapeHTML(u.name || u)}</option>`).join('');
                    new TomSelect(select,{plugins:['remove_button'],placeholder:'Todos los formadores...',onChange:()=>renderYear({preserveScroll:true})});
                }
            }
            buildSuggestionCatalog();
            const isUserInteracting = isDragging || transferBusy || document.querySelector('.calendar-editor-overlay,.calendar-clipboard-overlay,dialog[open]');
            if (!isUserInteracting) {
                renderYear({preserveScroll});
            } else {
                window._pendingCalendarRender = () => {
                    if (current() && !isDragging && !transferBusy && !document.querySelector('.calendar-editor-overlay,.calendar-clipboard-overlay,dialog[open]')) {
                        renderYear({preserveScroll: true});
                        window._pendingCalendarRender = null;
                    }
                };
            }
            if (window.triggerDailyTrainerNotification && session) window.triggerDailyTrainerNotification(session);
            if (scheduleRes.offline && !isBackground && !wasConnected) announce('Mostrando una copia sin conexión. No guardes cambios hasta volver a sincronizar.',true);
            if (!preserveScroll && !isBackground) requestAnimationFrame(()=>{if(current()) year===now.getFullYear() && focusMonth===now.getMonth()?scrollToToday(false):scrollToMonth(focusMonth,false);});
        } catch(error) {
            if (!current()) return;
            const months=container.querySelector('#calendarMonths');
            if (!preserveScroll || !calendarData) {
                const isAuth = /sesión|auth/i.test(error.message || '');
                months.innerHTML=`<div class="calendar-error"><strong>No hemos podido sincronizar el calendario</strong><span>${escapeHTML(error.message)}</span>${isAuth ? '<button type="button" class="btn-primary" id="calendarLoginBtn">Iniciar sesión</button>' : '<button type="button" class="btn-secondary" id="calendarRetry">Reintentar</button>'}</div>`;
                container.querySelector('#calendarRetry')?.addEventListener('click',()=>loadYear(selectedYear,focusMonth,true));
                container.querySelector('#calendarLoginBtn')?.addEventListener('click',()=>{ if (typeof clearSessionData==='function') clearSessionData(); window.location.hash='#'; });
            } else announce(error.message,true);
        } finally {
            if (current()) {loading.hidden=true;yearScroll.classList.remove('is-loading');}
        }
    }

    function buildSuggestionCatalog() {
        const seen = new Map();
        Object.values(calendarData.schedule || {}).forEach(daySchedule => {
            Object.values(daySchedule || {}).forEach(items => {
                (items || []).forEach(item => {
                    const text = String(item.text || "").trim();
                    if (!text) return;
                    const key = text.toLocaleLowerCase("es");
                    const current = seen.get(key);
                    if (current) current.frequency += 1;
                    else seen.set(key, { text, category: item.category || "otros", frequency: 1 });
                });
            });
        });

        try {
            const saved = JSON.parse(localStorage.getItem("xiaomiCalendarSuggestions") || "[]");
            saved.forEach(item => {
                const text = String(item.text || "").trim();
                if (text && !seen.has(text.toLocaleLowerCase("es"))) {
                    seen.set(text.toLocaleLowerCase("es"), { text, category: item.category || "otros", frequency: 1 });
                }
            });
        } catch (error) {
            console.warn("No se pudo recuperar el historial de actividades.", error);
        }

        suggestionCatalog = Array.from(seen.values())
            .sort((a, b) => b.frequency - a.frequency || a.text.localeCompare(b.text, "es"))
            .slice(0, 150);
    }

    function renderYear({ preserveScroll = false } = {}) {
        if (!calendarData) return;
        const oldScrollTop = preserveScroll ? yearScroll.scrollTop : 0;
        
        let selectedTrainers = [];
        if (isAdmin) {
            const filterSelect = container.querySelector("#calendarTrainerFilter");
            if (filterSelect && filterSelect.tomselect) {
                selectedTrainers = filterSelect.tomselect.getValue();
            }
        }

        const users = calendarData.users.filter(userObj => {
            const userId = typeof userObj === "object" ? userObj.user : userObj;
            const displayName = typeof userObj === "object" && userObj.name ? userObj.name : userId;
            if (userId === "Training Manager" || displayName === "Training Manager") return false;
            if (selectedTrainers.length > 0 && !selectedTrainers.includes(userId)) return false;
            return true;
        });

        container.querySelector("#calendarMonths").innerHTML = MONTHS.map((month, monthIndex) =>
            renderMonth(month, monthIndex, users)
        ).join("");

        bindCalendarInteractions();
        observeMonths();
        if (preserveScroll) yearScroll.scrollTop = oldScrollTop;
        if (typeof lucide !== "undefined") lucide.createIcons();
    }

    function renderMonth(monthName, monthIndex, users) {
        const firstDay = createLocalDate(selectedYear, monthIndex, 1);
        const lastDay = createLocalDate(selectedYear, monthIndex + 1, 0);
        const gridStart = new Date(firstDay);
        gridStart.setDate(gridStart.getDate() - ((gridStart.getDay() + 6) % 7));
        const gridEnd = new Date(lastDay);
        gridEnd.setDate(gridEnd.getDate() + (7 - gridEnd.getDay()) % 7);
        const weeks = [];
        const cursor = new Date(gridStart);

        while (cursor <= gridEnd) {
            const week = Array.from({ length: 7 }, (_, index) => {
                const date = new Date(cursor);
                date.setDate(cursor.getDate() + index);
                return date;
            });
            weeks.push(week);
            cursor.setDate(cursor.getDate() + 7);
        }

        const activityCount = Object.entries(calendarData.schedule || {}).reduce((total, [date, byUser]) => {
            if (!date.startsWith(`${selectedYear}-${String(monthIndex + 1).padStart(2, "0")}`)) return total;
            return total + Object.values(byUser || {}).reduce((sum, items) => sum + (items || []).length, 0);
        }, 0);

        return `
            <section class="calendar-month-section" id="calendar-month-${monthIndex}" data-month-section="${monthIndex}">
                <header class="calendar-month-heading">
                    <div><span>${String(monthIndex + 1).padStart(2, "0")}</span><h3>${monthName}</h3></div>
                    <p>${activityCount} ${activityCount === 1 ? "actividad" : "actividades"} planificadas</p>
                </header>
                <div class="calendar-month-weeks">
                    ${users.length ? weeks.map(week => renderWeek(week, monthIndex, users)).join("") : `
                        <div class="calendar-empty-filter">
                            <i data-lucide="user-search"></i><span>No hay formadores que coincidan con la búsqueda.</span>
                        </div>
                    `}
                </div>
            </section>
        `;
    }

    function renderWeek(days, monthIndex, users) {
        const weekNumber = getWeekNumber(days[0]);
        return `
            <div class="calendar-week-card" data-week="${weekNumber}">
                <div class="calendar-week-label">Semana ${weekNumber}</div>
                <div class="calendar-week-table-wrap" style="overflow-x: auto; max-width: 100%;">
                    <table class="calendar-weekly calendar-continuous-table">
                        <thead><tr>
                            <th class="trainer-col">Formador</th>
                            ${days.map((date, index) => `
                                <th class="${index >= 5 ? "day-wknd" : ""} ${toISO(date) === todayISO ? "is-today" : ""}">
                                    <span>${DAYS[index]}</span><strong>${date.getDate()}</strong>
                                </th>
                            `).join("")}
                        </tr></thead>
                        <tbody>
                            ${users.map(user => renderTrainerRow(user, days, monthIndex)).join("")}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    function renderTrainerRow(userObj, days, monthIndex) {
        const userId = typeof userObj === "object" ? userObj.user : userObj;
        const displayName = typeof userObj === "object" && userObj.name ? userObj.name : userId;
        return `
            <tr>
                <td class="trainer-col" title="${escapeHTML(userId)}">${escapeHTML(displayName)}</td>
                ${days.map((date, index) => renderDayCell(userId, date, monthIndex, index >= 5, displayName)).join("")}
            </tr>
        `;
    }

    function renderDayCell(userId, date, monthIndex, isWeekend, displayName = "") {
        const iso = toISO(date);
        const outsideMonth = date.getMonth() !== monthIndex;
        if (outsideMonth) return `<td class="day-cell day-outside ${isWeekend ? "day-wknd" : ""}" aria-hidden="true"></td>`;

        const blocks = calendarData.blocks || {};
        const userBlocks = blocks[userId] || blocks[String(userId).toLowerCase()] || (displayName ? (blocks[displayName] || blocks[String(displayName).toLowerCase()]) : {}) || {};
        const vacation = (userBlocks.vacationInfo || []).find(item => isInRange(iso, item.fechas));
        const isHoliday = userBlocks[iso] === "FESTIVO";
        const byDate = calendarData.schedule[iso] || {};
        const items = byDate[userId] || byDate[String(userId).toLowerCase()] || (displayName ? (byDate[displayName] || byDate[String(displayName).toLowerCase()]) : []) || [];
        const isMatchUser = userId === currentUser || displayName === currentUser || (String(currentUser).toLowerCase() === 'tl' && (String(userId).toLowerCase() === 'tl' || String(displayName).toLowerCase().includes('francisco')));
        const canEdit = !vacation && (isAdmin || (isMatchUser && !isWeekend && !isHoliday));
        const blocked = vacation || (!isAdmin && isHoliday) || !canEdit;
        let content = "";

        if (vacation) {
            content = `<div class="assignment-tag calendar-absence">${vacation.status === "Pendiente" ? "Solicitud" : "Vacaciones"}</div>`;
        } else {
            if (isHoliday) content += `<div class="assignment-tag cat-fest">Festivo</div>`;
            content += items.map((item, idx) => `
                <div class="assignment-tag cat-${escapeHTML(item.category || "otros")}" ${canEdit ? `draggable="true" data-index="${idx}"` : ""}>
                    <span class="assignment-tag-text">${linkify(item.text)}</span>
                    <button type="button" class="assignment-tag-copy" data-copy-item="${idx}" draggable="false" title="Copiar esta actividad" aria-label="Copiar actividad: ${escapeHTML(item.text)}">
                        <i data-lucide="copy"></i>
                    </button>
                </div>
            `).join("");
            if (!content && canEdit) content = `<span class="calendar-cell-empty">Añadir actividad</span>`;
        }

        return `
            <td class="day-cell ${isWeekend ? "day-wknd" : ""} ${blocked ? "day-blocked" : ""} ${iso === todayISO ? "is-today" : ""}"
                data-date="${iso}" data-user="${escapeHTML(userId)}" tabindex="${canEdit ? "0" : "-1"}" ${canEdit && items.length ? 'draggable="true"' : ""}
                aria-label="${escapeHTML(displayDate(date))}, ${escapeHTML(userId)}${items.length ? `, ${items.length} actividades` : ""}">
                <div class="calendar-cell-actions">
                    ${items.length ? `<button type="button" data-copy-day title="Copiar día" aria-label="Copiar actividades de este día"><i data-lucide="copy"></i></button>` : ""}
                    ${canEdit && getClipboards().length ? `<button type="button" data-paste-day title="Pegar en este día" aria-label="Pegar actividades en este día"><i data-lucide="clipboard-paste"></i></button>` : ""}
                    ${canEdit && items.length ? `<button type="button" class="calendar-delete-day" data-delete-day title="Borrar día" aria-label="Borrar todas las actividades de este día"><i data-lucide="trash-2"></i></button>` : ""}
                </div>
                ${content}
            </td>
        `;
    }

    function bindCalendarInteractions() {
        const monthsContainer = container.querySelector("#calendarMonths");
        if (!monthsContainer || monthsContainer.dataset.interactionsBound === "true") return;
        monthsContainer.dataset.interactionsBound = "true";

        monthsContainer.addEventListener("click", async event => {
            const cell = event.target.closest(".day-cell[data-date]");
            if (!cell || !monthsContainer.contains(cell)) return;

            // 1. Botón copiar actividad individual dentro de la pastilla
            const copyItemBtn = event.target.closest("[data-copy-item]");
            if (copyItemBtn) {
                event.stopPropagation();
                event.preventDefault();
                const itemIdx = Number(copyItemBtn.dataset.copyItem);
                const dayItems = getItems(cell.dataset.date, cell.dataset.user);
                const targetItem = dayItems[itemIdx];
                if (targetItem && targetItem.text.trim()) {
                    await copyActivity(targetItem, cell.dataset.user, cell.dataset.date);
                }
                return;
            }

            const items = () => getItems(cell.dataset.date, cell.dataset.user);
            const action = event.target.closest("[data-copy-day], [data-paste-day], [data-delete-day]");
            if (action) {
                event.stopPropagation();
                if (action.matches("[data-copy-day]")) copyDay(items(), cell.dataset.user, cell.dataset.date);
                if (action.matches("[data-paste-day]")) {
                    const clipboard = await pickClipboard();
                    if (clipboard?.items?.length) {
                        const currentItems = items();
                        if (currentItems.length) {
                            const addChoice = window.confirm("Este día ya tiene actividades planificadas.\n\n• Pulsa 'Aceptar' para AÑADIR la copia a las existentes\n• Pulsa 'Cancelar' para REEMPLAZAR las actividades del día");
                            const combined = addChoice ? currentItems.concat(deepCopyItems(clipboard.items)) : clipboard.items;
                            openEditPanel(cell.dataset.user, cell.dataset.date, combined, true);
                        } else {
                            openEditPanel(cell.dataset.user, cell.dataset.date, clipboard.items, true);
                        }
                    }
                }
                if (action.matches("[data-delete-day]")) await deleteDay(cell.dataset.user, cell.dataset.date, items(), action);
                return;
            }
            if (cell.tabIndex === 0 && !event.target.closest("a")) {
                openEditPanel(cell.dataset.user, cell.dataset.date, items());
            }
        });

        monthsContainer.addEventListener("keydown", event => {
            const cell = event.target.closest(".day-cell[data-date]");
            if (!cell || cell.tabIndex !== 0 || event.target.closest("button, a, input, select, textarea")) return;
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                openEditPanel(cell.dataset.user, cell.dataset.date, getItems(cell.dataset.date, cell.dataset.user));
            }
            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "v") {
                event.preventDefault();
                pickClipboard().then(clipboard => {
                    if (clipboard?.items?.length) openEditPanel(cell.dataset.user, cell.dataset.date, clipboard.items, true);
                });
            }
        });

        monthsContainer.addEventListener("dragstart", event => {
            if (event.target.closest("[data-copy-item]")) {
                event.preventDefault();
                return;
            }
            const pill = event.target.closest(".assignment-tag[draggable]");
            const cellDrag = event.target.closest(".day-cell[draggable]");
            
            if (pill) {
                isDragging = true;
                const cell = pill.closest(".day-cell[data-date]");
                event.dataTransfer.setData("application/json", JSON.stringify({
                    sourceUser: cell.dataset.user,
                    sourceDate: cell.dataset.date,
                    itemIndex: pill.dataset.index,
                    isFullDay: false
                }));
                event.dataTransfer.effectAllowed = "move";
                event.stopPropagation();
                setTimeout(() => pill.style.opacity = "0.5", 0);
            } else if (cellDrag) {
                isDragging = true;
                event.dataTransfer.setData("application/json", JSON.stringify({
                    sourceUser: cellDrag.dataset.user,
                    sourceDate: cellDrag.dataset.date,
                    isFullDay: true
                }));
                event.dataTransfer.effectAllowed = "move";
                setTimeout(() => cellDrag.style.opacity = "0.5", 0);
            } else {
                event.preventDefault();
            }
        });

        monthsContainer.addEventListener("dragend", event => {
            isDragging = false;
            const pill = event.target.closest(".assignment-tag");
            const cellDrag = event.target.closest(".day-cell");
            if (pill) pill.style.opacity = "";
            if (cellDrag) cellDrag.style.opacity = "";
            monthsContainer.querySelectorAll('.day-cell').forEach(el => el.style.boxShadow = "");
            window._pendingCalendarRender?.();
        });

        monthsContainer.addEventListener("dragover", event => {
            const cell = event.target.closest(".day-cell[data-date]:not(.day-blocked)");
            if (!cell || cell.tabIndex !== 0) return;
            event.preventDefault();
            event.dataTransfer.dropEffect = "move";
            cell.style.boxShadow = "inset 0 0 0 2px var(--xiaomi-orange)";
        });

        monthsContainer.addEventListener("dragleave", event => {
            const cell = event.target.closest(".day-cell");
            if (cell) cell.style.boxShadow = "";
        });

        monthsContainer.addEventListener('drop', async event => {
            event.preventDefault();
            const cell=event.target.closest('.day-cell[data-date]:not(.day-blocked)');
            if (!cell || cell.tabIndex!==0 || transferBusy) return;
            cell.style.boxShadow='';
            const raw=event.dataTransfer.getData('application/json');
            if (!raw) return;
            transferBusy=true;
            let prevSourceItems = null, prevTargetItems = null;
            let sDate = null, sUser = null, tDate = null, tUser = null;
            let sKey = null, tKey = null;
            try {
                ensureConnected();
                const data=JSON.parse(raw);
                sDate = data.sourceDate; sUser = data.sourceUser;
                tDate = cell.dataset.date; tUser = cell.dataset.user;
                if (sDate === tDate && sUser === tUser) return;
                const sourceVersion=revision(sDate,sUser) || '',targetVersion=revision(tDate,tUser) || '';
                const mode=await requestMoveOrCopy();
                if (!mode || !active()) return;

                // 1. Guardar estados previos para rollback en caso de fallo
                if (!calendarData.schedule) calendarData.schedule = {};
                calendarData.schedule[sDate] = calendarData.schedule[sDate] || {};
                calendarData.schedule[tDate] = calendarData.schedule[tDate] || {};
                sKey = getUserScheduleKey(sDate, sUser);
                tKey = getUserScheduleKey(tDate, tUser);
                prevSourceItems = deepCopyItems(calendarData.schedule[sDate][sKey] || []);
                prevTargetItems = deepCopyItems(calendarData.schedule[tDate][tKey] || []);

                const itemIdx = Number.isInteger(Number(data.itemIndex)) ? Number(data.itemIndex) : 0;

                // 2. Modificación optimista inmediata en memoria local
                const movingItems = data.isFullDay
                    ? deepCopyItems(prevSourceItems)
                    : (prevSourceItems[itemIdx] ? [{ text: String(prevSourceItems[itemIdx].text || ""), category: prevSourceItems[itemIdx].category || "otros" }] : []);

                if (!movingItems.length) return;

                if (mode === 'move') {
                    if (data.isFullDay) {
                        calendarData.schedule[sDate][sKey] = [];
                    } else {
                        const nextSource = deepCopyItems(prevSourceItems);
                        nextSource.splice(itemIdx, 1);
                        calendarData.schedule[sDate][sKey] = nextSource;
                    }
                }
                calendarData.schedule[tDate][tKey] = prevTargetItems.concat(movingItems);

                // 3. Re-renderizar la vista instantáneamente
                renderYear({ preserveScroll: true });
                announce(mode==='move'?'Moviendo actividad…':'Copiando actividad…');
                if (typeof showToast === 'function') {
                    showToast("Actualizando", mode==='move'?'Moviendo actividad en Google Sheets…':'Copiando actividad en Google Sheets…');
                }

                // 4. Enviar a Google Apps Script en segundo plano
                const response=await api.transferAssignment({
                    sourceDate: sDate,
                    sourceUser: sUser,
                    targetDate: tDate,
                    targetUser: tUser,
                    isFullDay: Boolean(data.isFullDay),
                    itemIndex: itemIdx,
                    mode,
                    sourceVersion,
                    targetVersion
                });
                if (response.status!=='success') throw new Error(response.message || 'El movimiento no se ha confirmado.');

                // 5. Persistencia offline local
                try {
                    setOfflineCacheEntry('getWeekly', { start: selectedYear + '-01-01', end: selectedYear + '-12-31' }, {
                        status: 'success',
                        source: 'matrix-v1',
                        schedule: calendarData.schedule,
                        versions: calendarData.versions,
                        capacities: calendarData.capacities,
                        users: calendarData.users,
                        blocks: calendarData.blocks
                    });
                } catch(eCache) {}

                announce(mode==='move'?'Actividades movidas y guardadas.':'Actividades copiadas y guardadas.');
                if (typeof showToast === 'function') {
                    showToast("¡Listo!", mode==='move'?'Actividades movidas y guardadas en la hoja.':'Actividades copiadas y guardadas en la hoja.');
                }
            } catch(error) {
                // Rollback si la llamada fallase
                if (prevSourceItems !== null && sDate && sKey) calendarData.schedule[sDate][sKey] = prevSourceItems;
                if (prevTargetItems !== null && tDate && tKey) calendarData.schedule[tDate][tKey] = prevTargetItems;
                renderYear({ preserveScroll: true });
                announce(error.message, true);
                if (typeof showToast === 'function') {
                    showToast("Error", error.message);
                }
            } finally {
                transferBusy = false;
                isDragging = false;
                window._pendingCalendarRender?.();
            }
        });
    }

    function getUserScheduleKey(date, userId) {
        if (!calendarData?.schedule?.[date]) return userId;
        const byDate = calendarData.schedule[date];
        if (byDate[userId]) return userId;
        const lower = String(userId).toLowerCase();
        if (byDate[lower]) return lower;
        const userObj = (calendarData.users || []).find(u => {
            const uid = (typeof u === 'object' ? u.user : u);
            const uname = (typeof u === 'object' && u.name ? u.name : '');
            return uid === userId || (uname && uname === userId);
        });
        const displayName = typeof userObj === 'object' && userObj.name ? userObj.name : '';
        if (displayName && byDate[displayName]) return displayName;
        if (displayName && byDate[displayName.toLowerCase()]) return displayName.toLowerCase();
        const objUserId = typeof userObj === 'object' && userObj.user ? userObj.user : '';
        if (objUserId && byDate[objUserId]) return objUserId;
        if (objUserId && byDate[objUserId.toLowerCase()]) return objUserId.toLowerCase();
        return userId;
    }

    function getItems(date, userId) {
        const byUser = calendarData.schedule[date] || {};
        const key = getUserScheduleKey(date, userId);
        return deepCopyItems(byUser[key] || []);
    }

    async function copyDay(items, userId, date) {
        const copied = await storeClipboardEntry(items, userId, date);
        if (!copied) return false;
        updateClipboardStatus();
        renderYear({ preserveScroll: true });
        announce(`Día copiado: ${items.length} ${items.length === 1 ? "actividad" : "actividades"}.`);
        if (typeof showToast === 'function') {
            showToast("¡Día copiado!", `${items.length} ${items.length === 1 ? "actividad copiada" : "actividades copiadas"}.`);
        }
        return true;
    }

    async function copyActivity(item, userId, date) {
        if (!item || !item.text.trim()) return false;
        const singleItem = [{ text: String(item.text || "").trim(), category: item.category || "otros" }];
        const copied = await storeClipboardEntry(singleItem, userId, date);
        if (!copied) return false;

        try {
            if (navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(item.text.trim());
            }
        } catch (eClip) {}

        updateClipboardStatus();
        renderYear({ preserveScroll: true });
        announce(`Actividad copiada: "${item.text.trim()}".`);
        if (typeof showToast === 'function') {
            showToast("¡Actividad copiada!", `"${item.text.trim()}" guardada en el portapapeles.`);
        }
        return true;
    }

    async function deleteDay(userId, date, items, triggerButton = null) {
        const savedItems = deepCopyItems(items).filter(item => item.text.trim());
        if (!savedItems.length) return false;

        const dateLabel = formatLongDate(date);
        const deletionComment = await requestDeleteConfirmation(userId, dateLabel);
        if (deletionComment === null) return false;

        const deleteVersion = revision(date,userId);
        const backupStored = await storeClipboardEntry(savedItems, userId, date);
        if (!backupStored) {
            announce("Borrado cancelado: no se eligió una ranura para la copia de seguridad.");
            return false;
        }
        updateClipboardStatus();

        // Actualización optimista: limpiar inmediatamente en memoria
        if (!calendarData.schedule) calendarData.schedule = {};
        if (!calendarData.schedule[date]) calendarData.schedule[date] = {};
        const prevDayItems = deepCopyItems(calendarData.schedule[date][userId] || []);
        calendarData.schedule[date][userId] = [];
        renderYear({ preserveScroll: true });

        try {
            const response = await saveDay({
                user: userId,
                date,
                items: [],
                modifiedBy: currentUser,
                expectedVersion: deleteVersion || '',
                deletionComment
            });
            if (response.status !== "success") throw new Error(response.message || "No se pudo borrar el día.");

            if (calendarData.versions) {
                calendarData.versions[date] = calendarData.versions[date] || {};
                calendarData.versions[date][userId] = response.version || Date.now();
            }
            try {
                setOfflineCacheEntry('getWeekly', { start: selectedYear + '-01-01', end: selectedYear + '-12-31' }, {
                    status: 'success',
                    source: 'matrix-v1',
                    schedule: calendarData.schedule,
                    versions: calendarData.versions,
                    capacities: calendarData.capacities,
                    users: calendarData.users,
                    blocks: calendarData.blocks
                });
            } catch(eCache) {}

            announce("Día borrado en Google Sheets. Sus actividades están en el portapapeles.");
            if (typeof showToast === 'function') {
                showToast("Día borrado", "Actividades eliminadas y respaldadas en el portapapeles.");
            }
            return true;
        } catch (error) {
            // Revertir en memoria si el backend rechaza
            calendarData.schedule[date][userId] = prevDayItems;
            renderYear({ preserveScroll: true });
            if (triggerButton) {
                triggerButton.disabled = false;
                triggerButton.removeAttribute("aria-busy");
                triggerButton.innerHTML = `<i data-lucide="trash-2"></i>`;
                if (typeof lucide !== "undefined") lucide.createIcons();
            }
            announce(`Error al borrar: ${error.message}`, true);
            if (typeof showToast === 'function') {
                showToast("Error", `No se pudo borrar en la hoja: ${error.message}`);
            }
            return false;
        }
    }

    function requestMoveOrCopy() {
        return new Promise(resolve => {
            const dialog = document.createElement("dialog");
            dialog.className = "calendar-delete-dialog";
            dialog.innerHTML = `
                <form method="dialog" class="calendar-delete-dialog-card" aria-labelledby="calendar-dnd-title">
                    <div class="calendar-delete-dialog-icon" aria-hidden="true" style="background:var(--bg-tertiary);color:var(--xiaomi-orange)"><i data-lucide="copy"></i></div>
                    <div class="calendar-delete-dialog-copy">
                        <span>Acción de calendario</span>
                        <h3 id="calendar-dnd-title">Mover o Copiar</h3>
                        <p>Has arrastrado una actividad a otro día. ¿Qué deseas hacer con ella?</p>
                    </div>
                    <div class="calendar-delete-dialog-actions" style="margin-top:20px; display:flex; gap:10px;">
                        <button type="button" class="btn-secondary" value="cancel" autofocus>Cancelar</button>
                        <button type="button" class="btn-primary" value="copy" style="flex:1">Copiar</button>
                        <button type="button" class="btn-primary" value="move" style="flex:1; background:#000;">Mover</button>
                    </div>
                </form>
            `;
            document.body.appendChild(dialog);
            if (typeof lucide !== 'undefined') lucide.createIcons({ root: dialog });
            
            const cleanup = (val) => {
                dialog.remove();
                resolve(val);
            };
            
            dialog.addEventListener("cancel", () => cleanup(null));
            dialog.addEventListener("close", () => cleanup(dialog.returnValue === "cancel" ? null : dialog.returnValue));
            
            dialog.querySelectorAll("button").forEach(btn => {
                btn.addEventListener("click", () => cleanup(btn.value === "cancel" ? null : btn.value));
            });
            
            dialog.showModal();
        });
    }

    function requestDeleteConfirmation(userId, dateLabel) {
        return new Promise(resolve => {
            const dialog = document.createElement("dialog");
            dialog.className = "calendar-delete-dialog";
            dialog.innerHTML = `
                <form method="dialog" class="calendar-delete-dialog-card" aria-labelledby="calendar-delete-title">
                    <div class="calendar-delete-dialog-icon" aria-hidden="true"><i data-lucide="trash-2"></i></div>
                    <div class="calendar-delete-dialog-copy">
                        <span>Acción permanente</span>
                        <h3 id="calendar-delete-title">Borrar actividades del día</h3>
                        <p>Se borrará la planificación de <strong>${escapeHTML(userId)}</strong> para el ${escapeHTML(dateLabel)}. Guardaremos una copia en el portapapeles para que puedas recuperarla.</p>
                    </div>
                    <label class="calendar-delete-comment">
                        <span>Comentario opcional</span>
                        <textarea rows="3" maxlength="500" placeholder="Motivo o contexto del borrado"></textarea>
                        <small>El comentario acompaña la solicitud. Esta versión no envía notificaciones automáticas.</small>
                    </label>
                    <div class="calendar-delete-dialog-actions">
                        <button type="button" class="btn-outline" data-keep>Conservar actividades</button>
                        <button type="submit" class="calendar-confirm-delete" value="delete"><i data-lucide="trash-2"></i>Borrar actividades</button>
                    </div>
                </form>
            `;
            document.body.appendChild(dialog);
            if (typeof lucide !== "undefined") lucide.createIcons();
            const textarea = dialog.querySelector("textarea");
            let settled = false;
            const finish = value => {
                if (settled) return;
                settled = true;
                resolve(value);
                dialog.remove();
            };
            dialog.querySelector("[data-keep]").addEventListener("click", () => {
                dialog.close("cancel");
                finish(null);
            });
            dialog.addEventListener("cancel", event => {
                event.preventDefault();
                dialog.close("cancel");
                finish(null);
            });
            dialog.addEventListener("close", () => {
                if (dialog.returnValue === "delete") finish(textarea.value.trim());
                else finish(null);
            });
            dialog.showModal();
            textarea.focus();
        });
    }

    function getClipboards() {
        try {
            const stored = JSON.parse(sessionStorage.getItem("xiaomiCalendarClipboards") || "null");
            if (Array.isArray(stored)) return stored.filter(entry => entry?.items?.length).slice(0, 2);
            const legacy = JSON.parse(sessionStorage.getItem("xiaomiCalendarClipboard") || "null");
            if (legacy?.items?.length) {
                sessionStorage.removeItem("xiaomiCalendarClipboard");
                sessionStorage.setItem("xiaomiCalendarClipboards", JSON.stringify([legacy]));
                return [legacy];
            }
            return [];
        } catch (error) {
            return [];
        }
    }

    function saveClipboards(entries) {
        sessionStorage.setItem("xiaomiCalendarClipboards", JSON.stringify(entries.slice(0, 2)));
    }

    async function storeClipboardEntry(items, userId, date) {
        const entry = { items: deepCopyItems(items), sourceUser: userId, sourceDate: date, copiedAt: Date.now() };
        const entries = getClipboards();
        if (entries.length < 2) entries.push(entry);
        else {
            const selected = await chooseClipboard(entries, "Portapapeles lleno", "Elige la copia que quieres reemplazar");
            if (!selected) return false;
            entries[selected.index] = entry;
        }
        saveClipboards(entries);
        return true;
    }

    async function pickClipboard() {
        const entries = getClipboards();
        if (entries.length === 0) return null;
        if (entries.length === 1) return entries[0];
        const selected = await chooseClipboard(entries, "¿Qué copia quieres pegar?", "Selecciona una de las dos copias disponibles");
        return selected?.entry || null;
    }

    function chooseClipboard(entries, title, subtitle) {
        return new Promise(resolve => {
            const overlay = document.createElement("div");
            overlay.className = "calendar-clipboard-overlay";
            overlay.innerHTML = `
                <section class="calendar-clipboard-picker" role="dialog" aria-modal="true" aria-labelledby="clipboard-picker-title">
                    <header>
                        <div><span>Máximo 2 copias</span><h3 id="clipboard-picker-title">${escapeHTML(title)}</h3><p>${escapeHTML(subtitle)}</p></div>
                        <button type="button" data-close aria-label="Cerrar"><i data-lucide="x"></i></button>
                    </header>
                    <div class="calendar-clipboard-options">
                        ${entries.map((entry, index) => `
                            <button type="button" data-clipboard-index="${index}">
                                <span class="calendar-clipboard-number">0${index + 1}</span>
                                <span class="calendar-clipboard-copy">
                                    <strong>${escapeHTML(formatLongDate(entry.sourceDate))}</strong>
                                    <small>${escapeHTML(entry.sourceUser)} · ${entry.items.length} ${entry.items.length === 1 ? "actividad" : "actividades"}</small>
                                    <em>${escapeHTML(entry.items.map(item => item.text).join(" · "))}</em>
                                </span>
                                <i data-lucide="chevron-right"></i>
                            </button>
                        `).join("")}
                    </div>
                </section>
            `;
            document.body.appendChild(overlay);
            const finish = result => {
                document.removeEventListener("keydown", onKeydown);
                overlay.remove();
                resolve(result);
            };
            const onKeydown = event => { if (event.key === "Escape") finish(null); };
            document.addEventListener("keydown", onKeydown);
            overlay.addEventListener("mousedown", event => { if (event.target === overlay) finish(null); });
            overlay.querySelector("[data-close]").addEventListener("click", () => finish(null));
            overlay.querySelectorAll("[data-clipboard-index]").forEach(button => {
                button.addEventListener("click", () => {
                    const index = Number(button.dataset.clipboardIndex);
                    finish({ index, entry: entries[index] });
                });
            });
            window.requestAnimationFrame(() => {
                overlay.classList.add("is-open");
                overlay.querySelector("[data-clipboard-index]")?.focus();
            });
            if (typeof lucide !== "undefined") lucide.createIcons();
        });
    }

    function updateClipboardStatus() {
        const status = container.querySelector("#calendarClipboardStatus");
        if (!status) return;
        const entries = getClipboards();
        status.classList.toggle("has-content", entries.length > 0);
        status.disabled = entries.length === 0;
        const text = entries.length
            ? `${entries.length}/2 ${entries.length === 1 ? "copia" : "copias"}${entries.length === 2 ? " · elegir al pegar" : ""}`
            : "Portapapeles vacío";
        status.querySelector("span").textContent = text;
    }

    function openEditPanel(userId, date, currentItems, pasted = false) {
        const editVersion = revision(date,userId);
        const returnFocus = document.activeElement;
        let workingItems = deepCopyItems(currentItems);
        const overlay = document.createElement("div");
        overlay.className = "calendar-editor-overlay";
        overlay.innerHTML = `
            <aside class="calendar-edit-panel" role="dialog" aria-modal="true" aria-labelledby="calendar-editor-title">
                <header class="calendar-editor-header">
                    <div>
                        <span>${escapeHTML(formatLongDate(date))}</span>
                        <h3 id="calendar-editor-title">${escapeHTML(userId)}</h3>
                    </div>
                    <button type="button" class="calendar-editor-close" aria-label="Cerrar"><i data-lucide="x"></i></button>
                </header>
                ${pasted ? `<div class="calendar-paste-notice"><i data-lucide="clipboard-check"></i>Contenido pegado. Revísalo antes de guardar.</div>` : ""}
                <div class="calendar-editor-tools">
                    <button type="button" data-editor-copy><i data-lucide="copy"></i>Copiar día</button>
                    <button type="button" data-editor-paste ${getClipboards().length ? "" : "disabled"}><i data-lucide="clipboard-paste"></i>Pegar</button>
                    <button type="button" data-editor-gcal title="Añadir a Google Calendar / Móvil"><i data-lucide="calendar-plus"></i>Añadir a mi Calendario</button>
                    ${currentItems.length ? `<button type="button" class="calendar-editor-delete" data-editor-delete><i data-lucide="trash-2"></i>Borrar día</button>` : ""}
                </div>
                <div class="calendar-assignment-list" data-items></div>
                <button type="button" class="calendar-add-assignment" data-add-item>
                    <i data-lucide="plus"></i>Añadir otra actividad
                </button>
                <footer class="calendar-editor-footer">
                    <span>Esc para cerrar</span>
                    <div>
                        <button type="button" class="btn-outline" data-cancel>Cancelar</button>
                        <button type="button" class="btn-primary" data-save><i data-lucide="check"></i>Guardar cambios</button>
                    </div>
                </footer>
            </aside>
        `;
        document.body.appendChild(overlay);
        document.body.classList.add("calendar-editor-open");
        const list = overlay.querySelector("[data-items]");

        const renderRows = () => {
            list.innerHTML = "";
            workingItems.forEach((item, index) => list.appendChild(createItemRow(item, index)));
            if (!workingItems.length) list.appendChild(createItemRow({ text: "", category: "osp" }, 0));
            if (typeof lucide !== "undefined") lucide.createIcons();
        };

        const close = () => {
            document.removeEventListener("keydown", onEscape);
            document.body.classList.remove("calendar-editor-open");
            overlay.classList.add("is-closing");
            returnFocus?.focus({preventScroll:true});
            window.setTimeout(() => overlay.remove(), 180);
        };
        const onEscape = event => {
            if (event.key==='Escape') close();
            if (event.key==='Tab') {
                const nodes=Array.from(overlay.querySelectorAll('button:not([disabled]),input,select,textarea,a[href]')).filter(el=>el.getClientRects().length);
                const first=nodes[0],last=nodes[nodes.length-1];
                if (event.shiftKey && document.activeElement===first) {event.preventDefault();last?.focus();}
                else if (!event.shiftKey && document.activeElement===last) {event.preventDefault();first?.focus();}
            }
        };
        document.addEventListener("keydown", onEscape);
        overlay.addEventListener("mousedown", event => { if (event.target === overlay) close(); });
        overlay.querySelector(".calendar-editor-close").addEventListener("click", close);
        overlay.querySelector("[data-cancel]").addEventListener("click", close);

        overlay.querySelector("[data-add-item]").addEventListener("click", () => {
            syncRows();
            workingItems.push({ text: "", category: "osp" });
            renderRows();
            list.lastElementChild?.querySelector(".calendar-activity-input")?.focus();
        });

        overlay.querySelector("[data-editor-copy]").addEventListener("click", async () => {
            syncRows();
            const nonEmptyItems = workingItems.filter(item => item.text.trim());
            if (nonEmptyItems.length) await copyDay(nonEmptyItems, userId, date);
        });

        overlay.querySelector("[data-editor-paste]").addEventListener("click", async () => {
            const clipboard = await pickClipboard();
            if (!clipboard?.items?.length) return;
            syncRows();
            const existingNonEmpty = workingItems.filter(item => item.text.trim());
            if (existingNonEmpty.length) {
                const addChoice = window.confirm("¿Deseas AÑADIR las actividades copiadas a las existentes de este día?\n\n• Aceptar: Añadirlas a las existentes\n• Cancelar: Reemplazar todo el día");
                if (addChoice) {
                    workingItems = existingNonEmpty.concat(deepCopyItems(clipboard.items));
                } else {
                    workingItems = deepCopyItems(clipboard.items);
                }
            } else {
                workingItems = deepCopyItems(clipboard.items);
            }
            renderRows();
            announce("Contenido pegado. Todavía no se ha guardado.");
            if (typeof showToast === 'function') {
                showToast("Pegado", "Actividades pegadas en el panel. Pulsa 'Guardar cambios'.");
            }
        });

        overlay.querySelector("[data-editor-gcal]")?.addEventListener("click", () => {
            syncRows();
            const nonEmptyItems = workingItems.filter(item => item.text && item.text.trim());
            openDayCalendarExport(userId, date, nonEmptyItems);
        });

        overlay.querySelector("[data-editor-delete]")?.addEventListener("click", async event => {
            const deleted = await deleteDay(userId, date, getItems(date, userId), event.currentTarget);
            if (deleted) close();
        });

        overlay.querySelector("[data-save]").addEventListener("click", async event => {
            syncRows();
            const newItems = workingItems
                .map(item => ({ text: item.text.trim(), category: item.category }))
                .filter(item => item.text);

            // 1. Guardar copia previa para rollback en caso de fallo
            if (!calendarData) calendarData = { schedule: {}, versions: {}, capacities: {} };
            if (!calendarData.schedule) calendarData.schedule = {};
            if (!calendarData.schedule[date]) calendarData.schedule[date] = {};
            const prevItems = deepCopyItems(calendarData.schedule[date][userId] || []);

            // 2. Actualización optimista inmediata en memoria de la app
            calendarData.schedule[date][userId] = newItems;
            rememberSuggestions(newItems);

            // 3. Re-renderizar el calendario al instante y cerrar el modal
            renderYear({ preserveScroll: true });
            close();

            // 4. Feedback instantáneo al usuario
            announce("Guardando en Google Sheets…");
            if (typeof showToast === 'function') {
                showToast("Guardando", "Actualizando tu planificación en Google Sheets…");
            }

            // 5. Enviar a Google Apps Script en segundo plano
            try {
                const response = await saveDay({
                    user: userId,
                    date,
                    items: newItems,
                    modifiedBy: currentUser,
                    expectedVersion: editVersion || ''
                });
                if (response.status !== "success") throw new Error(response.message || "No se pudo guardar.");

                if (calendarData.versions) {
                    calendarData.versions[date] = calendarData.versions[date] || {};
                    calendarData.versions[date][userId] = response.version || revision(date, userId) || Date.now();
                }

                // Sincronizar en caché offline local
                try {
                    setOfflineCacheEntry('getWeekly', { start: selectedYear + '-01-01', end: selectedYear + '-12-31' }, {
                        status: 'success',
                        source: 'matrix-v1',
                        schedule: calendarData.schedule,
                        versions: calendarData.versions,
                        capacities: calendarData.capacities,
                        users: calendarData.users,
                        blocks: calendarData.blocks
                    });
                } catch(eCache) {}

                announce("Planificación guardada en Google Sheets.");
                if (typeof showToast === 'function') {
                    showToast("¡Guardado!", "Planificación guardada con éxito en Google Sheets.");
                }
            } catch (error) {
                // Si falla el guardado en la nube, revertir en pantalla
                calendarData.schedule[date][userId] = prevItems;
                renderYear({ preserveScroll: true });
                announce(`Error al guardar: ${error.message}`, true);
                if (typeof showToast === 'function') {
                    showToast("Error de guardado", `No se pudo guardar en la hoja: ${error.message}`);
                }
            }
        });

        function syncRows() {
            workingItems = Array.from(list.querySelectorAll(".calendar-assignment-row")).map(row => ({
                text: row.querySelector(".calendar-activity-input").value,
                category: row.querySelector(".sel-cat").value
            }));
        }

        function createItemRow(item, index) {
            const row = document.createElement("div");
            row.className = "calendar-assignment-row";
            row.innerHTML = `
                <div class="calendar-row-index">${String(index + 1).padStart(2, "0")}</div>
                <div class="calendar-row-fields">
                    <select class="sel-cat" aria-label="Categoría de actividad">
                        ${categories.map(category => `
                            <option value="${category.id}" ${category.id === item.category ? "selected" : ""}>${category.label}</option>
                        `).join("")}
                    </select>
                    <div class="calendar-autocomplete">
                        <textarea class="calendar-activity-input" rows="2" placeholder="Escribe una actividad…" aria-label="Detalle de actividad">${escapeHTML(item.text)}</textarea>
                        <div class="calendar-suggestions" role="listbox"></div>
                    </div>
                </div>
                <div class="calendar-row-actions">
                    <button type="button" data-copy-row title="Copiar esta actividad" aria-label="Copiar esta actividad"><i data-lucide="copy"></i></button>
                    <button type="button" data-move-up aria-label="Subir actividad"><i data-lucide="chevron-up"></i></button>
                    <button type="button" data-move-down aria-label="Bajar actividad"><i data-lucide="chevron-down"></i></button>
                    <button type="button" data-remove aria-label="Eliminar actividad"><i data-lucide="trash-2"></i></button>
                </div>
            `;
            const input = row.querySelector(".calendar-activity-input");
            const categorySelect = row.querySelector(".sel-cat");
            const suggestions = row.querySelector(".calendar-suggestions");

            const showSuggestions = () => {
                const query = input.value.trim().toLocaleLowerCase("es");
                const matches = suggestionCatalog
                    .filter(suggestion => !query || suggestion.text.toLocaleLowerCase("es").includes(query))
                    .slice(0, 6);
                suggestions.innerHTML = matches.map(suggestion => `
                    <button type="button" role="option" data-text="${escapeHTML(suggestion.text)}" data-category="${escapeHTML(suggestion.category)}">
                        <span>${highlightMatch(suggestion.text, query)}</span>
                        <small>${escapeHTML(categoryLabel(suggestion.category))}</small>
                    </button>
                `).join("");
                suggestions.classList.toggle("is-visible", matches.length > 0 && (document.activeElement === input));
            };

            input.addEventListener("input", showSuggestions);
            input.addEventListener("focus", showSuggestions);
            input.addEventListener("blur", () => window.setTimeout(() => suggestions.classList.remove("is-visible"), 120));
            suggestions.addEventListener("mousedown", event => event.preventDefault());
            suggestions.addEventListener("click", event => {
                const option = event.target.closest("[data-text]");
                if (!option) return;
                input.value = option.dataset.text;
                categorySelect.value = option.dataset.category;
                suggestions.classList.remove("is-visible");
                input.focus();
            });

            row.querySelector("[data-copy-row]")?.addEventListener("click", () => {
                syncRows();
                const currentItem = workingItems[index];
                if (currentItem && currentItem.text.trim()) {
                    copyActivity(currentItem, userId, date);
                } else {
                    if (typeof showToast === 'function') {
                        showToast("Actividad vacía", "Escribe una actividad antes de copiarla.");
                    }
                }
            });

            row.querySelector("[data-remove]").addEventListener("click", () => {
                syncRows();
                workingItems.splice(index, 1);
                renderRows();
            });
            row.querySelector("[data-move-up]").addEventListener("click", () => {
                if (index === 0) return;
                syncRows();
                [workingItems[index - 1], workingItems[index]] = [workingItems[index], workingItems[index - 1]];
                renderRows();
            });
            row.querySelector("[data-move-down]").addEventListener("click", () => {
                syncRows();
                if (index >= workingItems.length - 1) return;
                [workingItems[index + 1], workingItems[index]] = [workingItems[index], workingItems[index + 1]];
                renderRows();
            });
            return row;
        }

        renderRows();
        window.requestAnimationFrame(() => {
            overlay.classList.add("is-open");
            list.querySelector(".calendar-activity-input")?.focus();
        });
        if (typeof lucide !== "undefined") lucide.createIcons();
    }

    function rememberSuggestions(items) {
        const merged = [...items, ...suggestionCatalog].reduce((map, item) => {
            const text = String(item.text || "").trim();
            if (text) map.set(text.toLocaleLowerCase("es"), { text, category: item.category || "otros" });
            return map;
        }, new Map());
        try {
            localStorage.setItem("xiaomiCalendarSuggestions", JSON.stringify(Array.from(merged.values()).slice(0, 150)));
        } catch (error) {
            console.warn("No se pudo guardar el historial local.", error);
        }
    }

    function observeMonths() {
        monthObserver?.disconnect();
        monthObserver = new IntersectionObserver(entries => {
            const visible = entries
                .filter(entry => entry.isIntersecting)
                .sort((a, b) => Math.abs(a.boundingClientRect.top) - Math.abs(b.boundingClientRect.top))[0];
            if (!visible) return;
            setActiveMonth(Number(visible.target.dataset.monthSection));
        }, { root: yearScroll, rootMargin: "-12% 0px -70% 0px", threshold: 0 });
        container.querySelectorAll("[data-month-section]").forEach(section => monthObserver.observe(section));
    }

    function setActiveMonth(monthIndex) {
        container.querySelector("#calendarActiveMonth").textContent = MONTHS[monthIndex];
        monthRail.querySelectorAll("[data-month]").forEach(button => {
            const active = Number(button.dataset.month) === monthIndex;
            button.classList.toggle("is-active", active);
            if (active) {
                monthRail.scrollTo({
                    left: Math.max(0, button.offsetLeft - (monthRail.clientWidth / 2) + (button.offsetWidth / 2)),
                    behavior: "smooth"
                });
            }
        });
    }

        function scrollToMonth(monthIndex, smooth) {
        const section = container.querySelector(`#calendar-month-${monthIndex}`);
        if (!section) return;
        yearScroll.style.scrollBehavior = smooth ? "smooth" : "auto";
        yearScroll.scrollTo({ top: Math.max(0, section.offsetTop - 8), behavior: smooth ? "smooth" : "auto" });
        setActiveMonth(monthIndex);
    }

        function scrollToToday(smooth) {
        yearScroll.style.scrollBehavior = smooth ? "smooth" : "auto";
        document.documentElement.style.scrollBehavior = smooth ? "smooth" : "auto";
        scrollToMonth(now.getMonth(), smooth);
        window.setTimeout(() => {
            const todayCell = container.querySelector(`[data-date="${todayISO}"][data-user]`);
            if (!todayCell) return;
            const currentWeekCard = todayCell.closest(".calendar-week-card");
            const scrollerRect = yearScroll.getBoundingClientRect();
            const cellRect = todayCell.getBoundingClientRect();
            const targetTop = currentWeekCard
                ? yearScroll.scrollTop + (currentWeekCard.getBoundingClientRect().top - scrollerRect.top) - 80
                : yearScroll.scrollTop + (cellRect.top - scrollerRect.top) - 80;
            const targetLeft = yearScroll.scrollLeft + (cellRect.left - scrollerRect.left) - (yearScroll.clientWidth / 2) + (cellRect.width / 2);
            yearScroll.scrollTo({
                top: Math.max(0, targetTop),
                left: Math.max(0, targetLeft),
                behavior: smooth ? "smooth" : "auto"
            });
            todayCell.focus({ preventScroll: true });
            window.scrollTo({ top: 0, left: 0, behavior: smooth ? "smooth" : "auto" });
            todayCell.classList.add("calendar-today-arrival");
            document.documentElement.style.scrollBehavior = "";
            yearScroll.style.scrollBehavior = "";
            window.setTimeout(() => todayCell.classList.remove("calendar-today-arrival"), 1100);
        }, smooth ? 360 : 60);
    }

    function announce(message, isError = false) {
        const region = container.querySelector("#calendarLiveRegion");
        if (region) region.textContent = message;
        if (typeof window.showToast === "function") {
            window.showToast(isError ? "No se pudo completar" : "Calendario", message);
        }
    }

    function linkify(text) {
        const escaped = escapeHTML(text);
        const urlRegex = /(https?:\/\/[^\s<]+|www\.[^\s<]+|meet\.google\.com\/[^\s<]+|teams\.microsoft\.com\/[^\s<]+)/gi;
        return escaped.replace(urlRegex, url => {
            const href = url.startsWith("http") ? url : `https://${url}`;
            return `<a href="${href}" target="_blank" rel="noopener noreferrer">Abrir enlace</a>`;
        });
    }

    function highlightMatch(text, query) {
        const safe = escapeHTML(text);
        if (!query) return safe;
        const index = text.toLocaleLowerCase("es").indexOf(query);
        if (index < 0) return safe;
        return `${escapeHTML(text.slice(0, index))}<mark>${escapeHTML(text.slice(index, index + query.length))}</mark>${escapeHTML(text.slice(index + query.length))}`;
    }

    function categoryLabel(categoryId) {
        return categories.find(category => category.id === categoryId)?.label || "Otros";
    }

    function displayDate(date) {
        return new Intl.DateTimeFormat("es-ES", { weekday: "long", day: "numeric", month: "long" }).format(date);
    }

    function formatLongDate(iso) {
        const [year, month, day] = iso.split("-").map(Number);
        return displayDate(createLocalDate(year, month - 1, day));
    }

    function isInRange(iso, rangeStr) {
        if (!rangeStr) return false;
        const matches = String(rangeStr).match(/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/g);
        if (!matches) return false;
        const parseRangeDate = value => {
            const [day, month, rawYear] = value.split("/").map(Number);
            return createLocalDate(rawYear < 100 ? rawYear + 2000 : rawYear, month - 1, day).getTime();
        };
        const [year, month, day] = iso.split("-").map(Number);
        const target = createLocalDate(year, month - 1, day).getTime();
        const start = parseRangeDate(matches[0]);
        const end = parseRangeDate(matches[matches.length - 1]);
        return target >= start && target <= end;
    }

    function getWeekNumber(dateValue) {
        const date = new Date(dateValue.getTime());
        date.setHours(0, 0, 0, 0);
        date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
        const weekOne = new Date(date.getFullYear(), 0, 4);
        return 1 + Math.round(((date.getTime() - weekOne.getTime()) / 86400000 - 3 + (weekOne.getDay() + 6) % 7) / 7);
    }

    function openDayCalendarExport(userId, date, items) {
        const validItems = (items || []).filter(it => it.text && it.text.trim() && !/^VACACIONES|^FESTIVO/i.test(it.text.trim()));
        if (!validItems.length) {
            if (typeof showToast === 'function') showToast("Sin actividades", "No hay actividades en este día para añadir al calendario.");
            return;
        }
        const summary = validItems.map(it => it.text.trim()).join(' · ');
        const parts = date.split('-');
        const dStart = parts[0] + parts[1] + parts[2];
        const nextDate = new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]) + 1));
        const dEnd = nextDate.toISOString().slice(0, 10).replace(/-/g, '');
        
        const gCalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(summary)}&dates=${dStart}/${dEnd}&details=${encodeURIComponent('Planificación de formación Xiaomi: ' + summary)}&location=España&sf=true&output=xml`;
        window.open(gCalUrl, '_blank', 'noopener,noreferrer');
        if (typeof showToast === 'function') showToast("Abriendo calendario", "Guardando el evento con recordatorio en tu calendario.");
    }

    async function getTrainerICSContent(trainerId, year) {
        const targetTrainer = trainerId || currentUser;
        const isAllTrainers = targetTrainer === 'ALL' || ['Training Manager', 'Training Coordinator', 'Training Creator'].includes(targetTrainer);
        const events = [];
        const nowStr = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '') + 'Z';

        const trainersList = (calendarData?.users || []).filter(u => {
            const uid = typeof u === 'object' ? u.user : u;
            return !['Training Manager', 'Training Coordinator', 'Training Creator'].includes(uid);
        });

        const getTrainerDisplayName = (tId) => {
            if (isAllTrainers) return 'Equipo Completo';
            const found = trainersList.find(u => {
                const uid = typeof u === 'object' ? u.user : u;
                const name = typeof u === 'object' ? u.name : u;
                return uid === tId || name === tId;
            });
            return found ? (typeof found === 'object' ? (found.name || found.user) : found) : tId;
        };

        if (calendarData?.schedule) {
            const dates = Object.keys(calendarData.schedule).filter(d => d.startsWith(String(year))).sort();
            const targets = isAllTrainers
                ? trainersList.map(u => ({
                    id: typeof u === 'object' ? u.user : u,
                    name: typeof u === 'object' ? (u.name || u.user) : u
                }))
                : [{ id: targetTrainer, name: getTrainerDisplayName(targetTrainer) }];

            dates.forEach(date => {
                const parts = date.split('-');
                const dStart = parts[0] + parts[1] + parts[2];
                const nextDate = new Date(Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]) + 1));
                const dEnd = nextDate.toISOString().slice(0, 10).replace(/-/g, '');

                targets.forEach(tObj => {
                    const items = getItems(date, tObj.id);
                    items.forEach((item, idx) => {
                        const text = String(item.text || '').trim();
                        if (!text || /^VACACIONES|^FESTIVO/i.test(text)) return;
                        const safeUidTrainer = String(tObj.id).replace(/[^a-zA-Z0-9_-]/g, '');
                        const uid = `xiaomi-${date}-${idx}-${safeUidTrainer}@xiaomitrainer`;
                        const rawSummary = isAllTrainers ? `[${tObj.name}] ${text}` : text;
                        const cleanSummary = rawSummary.replace(/[\r\n]+/g, ' - ').replace(/,/g, '\\,').replace(/;/g, '\\;');
                        const cat = String(item.category || 'otros').toUpperCase();

                        events.push([
                            "BEGIN:VEVENT",
                            "UID:" + uid,
                            "DTSTAMP:" + nowStr,
                            "DTSTART;VALUE=DATE:" + dStart,
                            "DTEND;VALUE=DATE:" + dEnd,
                            "SUMMARY:" + cleanSummary,
                            "DESCRIPTION:Formación Xiaomi (" + cat + ") - " + cleanSummary,
                            "CATEGORIES:" + cat,
                            "STATUS:CONFIRMED",
                            "TRANSP:OPAQUE",
                            "BEGIN:VALARM",
                            "ACTION:DISPLAY",
                            "DESCRIPTION:Recordatorio de formación: " + cleanSummary,
                            "TRIGGER:-PT1H",
                            "END:VALARM",
                            "END:VEVENT"
                        ].join("\r\n"));
                    });
                });
            });
        }

        if (events.length > 0) {
            const calLabel = getTrainerDisplayName(targetTrainer);
            return [
                "BEGIN:VCALENDAR",
                "VERSION:2.0",
                "PRODID:-//Xiaomi Trainer Platform//ES",
                "CALSCALE:GREGORIAN",
                "METHOD:PUBLISH",
                "X-WR-CALNAME:Xiaomi Formaciones " + year + " - " + calLabel,
                "X-WR-TIMEZONE:Europe/Madrid",
                events.join("\r\n"),
                "END:VCALENDAR"
            ].join("\r\n");
        }

        // Fallback: descargar feed directo generado en el backend por Apps Script si no hay eventos locales
        const apiEndpoint = (typeof API_URL !== 'undefined') ? API_URL : '';
        if (apiEndpoint) {
            try {
                const feedUser = isAllTrainers ? 'ALL' : targetTrainer;
                const feedUrl = `${apiEndpoint}?action=calendarFeed&user=${encodeURIComponent(feedUser)}&year=${year}`;
                const resp = await fetch(feedUrl);
                if (resp.ok) {
                    const icsText = await resp.text();
                    if (icsText && icsText.includes('BEGIN:VCALENDAR') && icsText.includes('BEGIN:VEVENT')) {
                        return icsText;
                    }
                }
            } catch (err) {
                console.warn('No se pudo obtener el feed de calendario remoto:', err);
            }
        }

        return null;
    }

    function triggerICSFileDownload(icsContent, fileName) {
        const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        return blob;
    }

    async function smartSyncTrainerICS(trainerId, year, options = {}) {
        const targetTrainer = trainerId || currentUser;
        if (typeof showToast === 'function') {
            showToast("Preparando calendario", "Compilando las formaciones con recordatorios...");
        }

        const icsContent = await getTrainerICSContent(targetTrainer, year);
        if (!icsContent) {
            if (typeof showToast === 'function') {
                showToast("Sin actividades", "No se encontraron actividades registradas en " + year + " para exportar.");
            }
            return null;
        }

        const isAll = targetTrainer === 'ALL' || ['Training Manager', 'Training Coordinator', 'Training Creator'].includes(targetTrainer);
        const safeName = isAll ? 'Equipo_Xiaomi' : String(targetTrainer).replace(/[^a-zA-Z0-9_\u00C0-\u017F]+/g, '_');
        const fileName = `xiaomi_formaciones_${safeName}_${year}.ics`;

        // Modo Google Calendar: descarga el archivo .ics y abre la pantalla oficial de Importación de Google Calendar
        if (options.openGoogleCalendarImport) {
            triggerICSFileDownload(icsContent, fileName);
            window.open('https://calendar.google.com/calendar/r/settings/export', '_blank', 'noopener,noreferrer');
            if (typeof showToast === 'function') {
                showToast("Archivo .ics descargado", "Selecciona el archivo descargado en la pantalla 'Importar' de Google Calendar.");
            }
            return fileName;
        }

        // Si el usuario pulsa compartir explícitamente en móvil
        if (options.useNativeShare && typeof File !== 'undefined' && navigator.canShare) {
            try {
                const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
                const file = new File([blob], fileName, { type: 'text/calendar' });
                if (navigator.canShare({ files: [file] })) {
                    await navigator.share({
                        files: [file],
                        title: `Xiaomi Formaciones ${year}`,
                        text: `Calendario de formaciones Xiaomi (${year})`
                    });
                    return fileName;
                }
            } catch (shareErr) {
                if (shareErr.name === 'AbortError') return null;
            }
        }

        // Descarga directa del archivo .ics (en Android/iOS al abrir el archivo descargado se abre Google Calendar / Apple Calendar directamente)
        triggerICSFileDownload(icsContent, fileName);
        if (typeof showToast === 'function') {
            showToast("Calendario descargado", `Abre el archivo '${fileName}' para añadir todas las citas a tu Calendario.`);
        }
        return fileName;
    }

    const downloadTrainerICS = smartSyncTrainerICS;

    window.triggerDailyTrainerNotification = async function(userSession, forceTest = false) {
        if (!('Notification' in window)) return;
        const isEnabled = localStorage.getItem('xiaomiDailyNotif') === 'true';
        if (!forceTest && !isEnabled) return;
        if (Notification.permission !== 'granted') return;

        const nowLocal = new Date();
        const pad = n => String(n).padStart(2, '0');
        const todayStr = `${nowLocal.getFullYear()}-${pad(nowLocal.getMonth() + 1)}-${pad(nowLocal.getDate())}`;

        if (!forceTest) {
            const lastNotif = localStorage.getItem('xiaomiLastDailyNotifDate');
            if (lastNotif === todayStr) return;
        }

        const targetUser = userSession?.displayName || userSession?.user || currentUser;
        let todayItems = [];
        if (calendarData?.schedule?.[todayStr]) {
            todayItems = getItems(todayStr, targetUser).filter(it => {
                const txt = String(it.text || '').trim();
                return txt && !/^VACACIONES|^FESTIVO/i.test(txt);
            });
        }

        let title = '';
        let body = '';

        if (todayItems.length > 0) {
            const list = todayItems.map(it => it.text).join(' · ');
            title = `Xiaomi Trainer · Hoy (${todayItems.length} actividad${todayItems.length > 1 ? 'es' : ''})`;
            body = list;
        } else if (forceTest) {
            title = 'Xiaomi Trainer · Avisos en Pantalla';
            body = '¡Notificaciones activadas correctamente! Te avisaremos a primera hora únicamente los días con actividades programadas.';
        } else {
            return; // No hay actividad hoy
        }

        if (!forceTest) {
            localStorage.setItem('xiaomiLastDailyNotifDate', todayStr);
        }

        // Enviar por Service Worker para soporte móvil en segundo plano
        try {
            if ('serviceWorker' in navigator) {
                const reg = await navigator.serviceWorker.ready;
                if (reg && reg.showNotification) {
                    await reg.showNotification(title, {
                        body,
                        icon: './Xiaomi_logo_(2021-).svg.png',
                        badge: './Xiaomi_logo_(2021-).svg.png',
                        tag: 'xiaomi-daily-' + (forceTest ? 'test-' + Date.now() : todayStr),
                        data: { url: './#calendar' },
                        renotify: true
                    });
                    return;
                }
            }
        } catch (swErr) {
            console.warn('Fallo en notificación via Service Worker:', swErr);
        }

        try {
            new Notification(title, {
                body,
                icon: './Xiaomi_logo_(2021-).svg.png',
                tag: 'xiaomi-daily'
            });
        } catch (nErr) {
            console.warn('Fallo en Notification API directa:', nErr);
        }
    };

    function showPhoneSyncDialog() {
        const dialog = document.createElement("dialog");
        dialog.className = "calendar-sync-phone-dialog";
        
        const trainersList = (calendarData?.users || []).filter(u => {
            const uid = typeof u === 'object' ? u.user : u;
            return !['Training Manager', 'Training Coordinator', 'Training Creator'].includes(uid);
        });

        // Determinar formador predeterminado: si el usuario es un formador, preseleccionarlo; si es manager, usar el filtro o el primer formador
        let defaultTarget = currentUser;
        const isManagerAccount = ['Training Manager', 'Training Coordinator', 'Training Creator'].includes(currentUser);
        if (isManagerAccount) {
            const filterSelect = container.querySelector("#calendarTrainerFilter");
            const activeFilters = filterSelect?.tomselect ? filterSelect.tomselect.getValue() : [];
            if (Array.isArray(activeFilters) && activeFilters.length === 1) {
                defaultTarget = activeFilters[0];
            } else {
                defaultTarget = trainersList[0] ? (typeof trainersList[0] === 'object' ? trainersList[0].user : trainersList[0]) : 'ALL';
            }
        }

        const apiEndpoint = (typeof API_URL !== 'undefined') ? API_URL : '';
        const getFeedUrls = (userVal) => {
            const feedUser = (userVal === 'ALL' || isManagerAccount && userVal === currentUser) ? 'ALL' : userVal;
            const baseFeedUrl = `${apiEndpoint}?action=calendarFeed&user=${encodeURIComponent(feedUser)}&year=${selectedYear}`;
            const webcalUrl = `webcal://${apiEndpoint.replace(/^https?:\/\//, '')}?action=calendarFeed&user=${encodeURIComponent(feedUser)}&year=${selectedYear}`;
            return { baseFeedUrl, webcalUrl };
        };

        const initialUrls = getFeedUrls(defaultTarget);
        const notifSupported = 'Notification' in window;
        const notifGranted = notifSupported && Notification.permission === 'granted';
        const notifEnabled = notifGranted && localStorage.getItem('xiaomiDailyNotif') === 'true';

        const getTrainerName = (uid) => {
            if (uid === 'ALL') return 'Equipo completo';
            const found = trainersList.find(u => (typeof u === 'object' ? u.user : u) === uid);
            return found ? (typeof found === 'object' ? (found.name || found.user) : found) : uid;
        };

        dialog.innerHTML = `
            <div class="calendar-phone-dialog-card">
                <header class="calendar-phone-dialog-header">
                    <div class="calendar-phone-icon"><i data-lucide="smartphone"></i></div>
                    <div>
                        <h3>Móvil y Sincronización</h3>
                        <p>Integra tus formaciones con Google Calendar o tu móvil con actualización automática o descarga puntual.</p>
                    </div>
                    <button type="button" class="btn-close-dialog" data-close-dialog aria-label="Cerrar"><i data-lucide="x"></i></button>
                </header>

                <div class="calendar-phone-dialog-body">
                    <!-- SELECTOR DE CALENDARIO / FORMADOR (SIEMPRE VISIBLE) -->
                    <div style="background: var(--bg-hover, rgba(0,0,0,0.03)); border: 1px solid var(--border-color); border-radius: 12px; padding: 12px 14px; margin-bottom: 14px;">
                        <label for="syncTrainerSelect" style="display: block; font-size: 0.84rem; font-weight: 700; color: var(--text-main); margin-bottom: 6px;">
                            <i data-lucide="user-check" style="width: 16px; height: 16px; vertical-align: -2px; margin-right: 4px; color: var(--xiaomi-orange);"></i>
                            ¿Qué formador o calendario deseas sincronizar?
                        </label>
                        <select id="syncTrainerSelect" class="form-control" style="width: 100%; padding: 0.6rem 0.8rem; border-radius: 10px; border: 1px solid var(--border-color); background: var(--bg-card); color: var(--text-main); font-size: 0.92rem; font-weight: 600;">
                            ${trainersList.map(u => {
                                const uid = typeof u === 'object' ? u.user : u;
                                const name = typeof u === 'object' ? (u.name || u.user) : u;
                                const isSelf = uid === currentUser;
                                return `<option value="${escapeHTML(uid)}" ${defaultTarget === uid ? 'selected' : ''}>${escapeHTML(name)}${isSelf ? ' (Mi calendario)' : ''}</option>`;
                            }).join('')}
                            <option value="ALL" ${defaultTarget === 'ALL' ? 'selected' : ''}>Todos los formadores (Equipo completo)</option>
                        </select>
                        <small style="display:block; color:var(--text-muted); font-size:0.75rem; margin-top:4px;">
                            Selecciona tu nombre para sincronizar únicamente tus eventos, o elige "Equipo completo" para ver todas las formaciones.
                        </small>
                    </div>

                    <!-- MÉTODO 1: SUSCRIPCIÓN EN TIEMPO REAL (AUTOMÁTICA) -->
                    <div class="phone-sync-section" style="border-left: 3px solid #2196f3; padding-left: 12px;">
                        <div class="phone-sync-sec-title">
                            <i data-lucide="refresh-cw" style="color: #2196f3;"></i>
                            <div>
                                <strong style="color: #2196f3;">Método 1 · Suscripción Automática en Tiempo Real (Recomendado)</strong>
                                <span style="font-size:0.78rem;">¡Se actualiza solo! Te suscribes una única vez y tu calendario se sincroniza automáticamente cada vez que se añadan o editen actividades en la intranet.</span>
                            </div>
                        </div>

                        <div style="background: rgba(33,150,243,0.06); border: 1px solid rgba(33,150,243,0.2); border-radius: 10px; padding: 10px 12px; margin-top: 8px; font-size: 0.78rem; line-height: 1.45; color: var(--text-main);">
                            <strong>¿Cómo activarlo en Google Calendar?</strong><br>
                            1. Pulsa el botón <strong>«Copiar enlace iCal»</strong> de abajo.<br>
                            2. En Google Calendar (<a href="https://calendar.google.com" target="_blank" rel="noopener,noreferrer" style="color:#2196f3; text-decoration:underline;">calendar.google.com</a>), en la barra izquierda junto a <strong>«Otros calendarios»</strong>, pulsa <strong>«+»</strong> ➔ <strong>«Desde una URL»</strong>.<br>
                            3. Pega el enlace y pulsa <strong>«Añadir calendario»</strong>. ¡Listo! Se actualizará solo en tu PC y en la app de tu móvil.
                        </div>

                        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
                            <button type="button" class="btn-primary" id="btnCopyFeedUrl" style="background:#2196f3; border-color:#2196f3; font-size:0.82rem; padding:0.55rem 0.95rem; font-weight:600;">
                                <i data-lucide="copy"></i><span>Copiar enlace iCal de <strong id="lblSyncCopyName">${escapeHTML(getTrainerName(defaultTarget))}</strong></span>
                            </button>
                            <a href="${escapeHTML(initialUrls.webcalUrl)}" id="linkWebcalSub" class="btn-secondary" style="text-decoration:none; display:inline-flex; align-items:center; gap:6px; font-size:0.82rem; padding:0.55rem 0.9rem;">
                                <i data-lucide="calendar"></i><span>Apple Calendar / Webcal</span>
                            </a>
                        </div>
                    </div>

                    <!-- MÉTODO 2: DESCARGA DE ARCHIVO .ICS (COPIA ESTÁTICA PUNTUAL) -->
                    <div class="phone-sync-section" style="border-left: 3px solid var(--xiaomi-orange); padding-left: 12px; margin-top: 14px;">
                        <div class="phone-sync-sec-title">
                            <i data-lucide="download" style="color: var(--xiaomi-orange);"></i>
                            <div>
                                <strong>Método 2 · Descarga de archivo .ics (Copia estática puntual)</strong>
                                <span style="font-size:0.78rem;">Descarga una copia fija con las citas actuales del año ${selectedYear}. Si se añaden nuevas actividades más adelante, no se sincronizan solas; tendrías que volver a descargarlo.</span>
                            </div>
                        </div>

                        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
                            <button type="button" class="btn-secondary" id="btnSmartSync" style="display:inline-flex; align-items:center; gap:6px; font-size:0.82rem; padding:0.55rem 0.9rem; font-weight:600;">
                                <i data-lucide="download"></i><span>Descargar archivo .ics (<strong id="lblDownloadName">${escapeHTML(getTrainerName(defaultTarget))}</strong>)</span>
                            </button>
                            <button type="button" class="btn-outline" id="btnGCalImport" style="font-size:0.82rem; padding:0.55rem 0.9rem;">
                                <i data-lucide="external-link"></i><span>Subir .ics a Google Calendar</span>
                            </button>
                        </div>

                        <div id="gcalImportHelper" style="display:none; margin-top:8px; padding:10px 12px; border-radius:10px; background:rgba(255,103,0,0.09); border:1px solid rgba(255,103,0,0.3); font-size:0.78rem; line-height:1.45; color:var(--text-main);">
                            <strong style="color:var(--xiaomi-orange); display:block; margin-bottom:4px;">✓ Archivo <code id="gcalHelperFileName">.ics</code> descargado:</strong>
                            1. En la pestaña de <strong>Google Calendar</strong> que se ha abierto, pulsa <strong>«Seleccionar el archivo de tu ordenador»</strong>.<br>
                            2. Elige el archivo <code>.ics</code> descargado y pulsa <strong>«Importar»</strong>.
                        </div>
                    </div>

                    <!-- SECCIÓN 3: AVISOS DIARIOS EN PANTALLA -->
                    <div class="phone-sync-section" style="margin-top: 14px;">
                        <div class="phone-sync-sec-title">
                            <i data-lucide="bell"></i>
                            <div>
                                <strong>3. Avisos diarios en pantalla (Notificaciones Web)</strong>
                                <span>Aviso emergente matinal discreto solo los días que tengas actividades programadas.</span>
                            </div>
                        </div>

                        <div class="phone-notif-toggle-row">
                            <div class="phone-notif-toggle-copy">
                                <strong>Aviso matinal los días con formación</strong>
                                <small id="notifStatusText">${
                                    !notifSupported
                                        ? 'Este navegador no soporta notificaciones web.'
                                        : (notifEnabled ? 'Activo ✓ · Recibirás un aviso en pantalla los días con actividad.' : 'Desactivado · No se mostrarán avisos en pantalla.')
                                }</small>
                            </div>
                            <label class="switch-toggle" style="${!notifSupported ? 'opacity:0.5; pointer-events:none;' : ''}">
                                <input type="checkbox" id="dailyNotifSwitch" ${notifEnabled ? 'checked' : ''}>
                                <span class="slider-round"></span>
                            </label>
                        </div>
                    </div>
                </div>

                <footer class="calendar-phone-dialog-footer">
                    <button type="button" class="btn-primary" data-close-dialog>Entendido</button>
                </footer>
            </div>
        `;
        document.body.appendChild(dialog);
        if (typeof lucide !== 'undefined') lucide.createIcons({ root: dialog });

        const close = () => {
            dialog.close();
            dialog.remove();
        };

        dialog.querySelectorAll("[data-close-dialog]").forEach(btn => btn.addEventListener("click", close));
        dialog.addEventListener("cancel", () => dialog.remove());

        const getSelectedTarget = () => {
            const sel = dialog.querySelector("#syncTrainerSelect");
            return sel ? sel.value : defaultTarget;
        };

        const updateDialogLabels = (targetVal) => {
            const name = getTrainerName(targetVal);
            const lblCopy = dialog.querySelector("#lblSyncCopyName");
            if (lblCopy) lblCopy.textContent = name;
            const lblDl = dialog.querySelector("#lblDownloadName");
            if (lblDl) lblDl.textContent = name;
            const urls = getFeedUrls(targetVal);
            const webcalLink = dialog.querySelector("#linkWebcalSub");
            if (webcalLink) webcalLink.href = urls.webcalUrl;
        };

        dialog.querySelector("#syncTrainerSelect")?.addEventListener("change", (e) => {
            updateDialogLabels(e.target.value);
        });

        // Botón Opción A: Subir .ics a Google Calendar (Descarga .ics + Abre Importar de Google Calendar)
        dialog.querySelector("#btnGCalImport")?.addEventListener("click", async () => {
            const fileName = await smartSyncTrainerICS(getSelectedTarget(), selectedYear, { openGoogleCalendarImport: true });
            if (fileName) {
                const helper = dialog.querySelector("#gcalImportHelper");
                const codeEl = dialog.querySelector("#gcalHelperFileName");
                if (codeEl) codeEl.textContent = fileName;
                if (helper) helper.style.display = "block";
            }
        });

        // Botón Opción B: Descargar archivo .ics directo (para abrir en móvil / Outlook / Apple)
        dialog.querySelector("#btnSmartSync")?.addEventListener("click", () => {
            smartSyncTrainerICS(getSelectedTarget(), selectedYear);
        });

        // Copiar enlace de suscripción en tiempo real
        dialog.querySelector("#btnCopyFeedUrl")?.addEventListener("click", async () => {
            const urls = getFeedUrls(getSelectedTarget());
            try {
                await navigator.clipboard.writeText(urls.baseFeedUrl);
                if (typeof showToast === 'function') showToast("Enlace copiado", `Enlace de suscripción en tiempo real para ${getTrainerName(getSelectedTarget())} copiado.`);
            } catch(e) {
                if (typeof showToast === 'function') showToast("Enlace de suscripción", urls.baseFeedUrl);
            }
        });

        // Switch de notificaciones (Punto 3)
        const toggleSwitch = dialog.querySelector("#dailyNotifSwitch");
        const statusText = dialog.querySelector("#notifStatusText");
        toggleSwitch?.addEventListener("change", async (e) => {
            if (e.target.checked) {
                if (!('Notification' in window)) {
                    if (typeof showToast === 'function') showToast("No compatible", "Tu navegador no admite notificaciones.");
                    e.target.checked = false;
                    return;
                }
                let permission = Notification.permission;
                if (permission !== 'granted') {
                    permission = await Notification.requestPermission();
                }
                if (permission === 'granted') {
                    localStorage.setItem('xiaomiDailyNotif', 'true');
                    if (statusText) statusText.textContent = 'Activo ✓ · Recibirás un aviso en pantalla los días con actividad.';
                    if (typeof showToast === 'function') showToast("Avisos activados", "Te hemos enviado una notificación de prueba para comprobar que funciona.");
                    if (window.triggerDailyTrainerNotification && session) {
                        window.triggerDailyTrainerNotification(session, true);
                    }
                } else {
                    localStorage.setItem('xiaomiDailyNotif', 'false');
                    e.target.checked = false;
                    if (statusText) statusText.textContent = 'Permiso no concedido en el navegador.';
                    if (typeof showToast === 'function') showToast("Permiso no concedido", "Activa las notificaciones en los ajustes de tu navegador.");
                }
            } else {
                localStorage.setItem('xiaomiDailyNotif', 'false');
                if (statusText) statusText.textContent = 'Desactivado · No se mostrarán avisos en pantalla.';
                if (typeof showToast === 'function') showToast("Avisos desactivados", "No se enviarán avisos en pantalla en este dispositivo.");
            }
        });

        dialog.showModal();
    }
}

window.renderCalendar = renderCalendar;

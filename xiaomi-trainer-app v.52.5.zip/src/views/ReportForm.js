function renderReport(container, editData = null) {
    const session = getSessionData();
    const currentUser = session ? session.user : '';
    const role = session ? session.role : '';
    let isLoadingEdit = !!editData;
    if (editData) {
        editData = Object.fromEntries(Object.entries(editData).map(([key, value]) => [
            key,
            typeof value === 'string' && window.escapeHTML ? window.escapeHTML(value) : value
        ]));
    }

    const distribuidores = {
        "MediaMarkt": [
            "Central", "MediaMarkt Barcelona - Francesc Macià", "MediaMarkt Cornellà-El Prat", "MediaMarkt Diagonal Mar", "MediaMarkt Esplugues", 
            "MediaMarkt Gavà", "MediaMarkt La Maquinista", "MediaMarkt Mataró", "MediaMarkt Badalona", "MediaMarkt Parets del Vallès", 
            "MediaMarkt Plaza Cataluña", "MediaMarkt Ronda Sant Antoni", "MediaMarkt Sabadell", "MediaMarkt Sant Cugat", 
            "MediaMarkt Terrassa", "MediaMarkt Vilanova i la Geltrú", "MediaMarkt Girona", "MediaMarkt Parc d'Aro", 
            "MediaMarkt Porta Lloret", "MediaMarkt Lleida", "MediaMarkt Tarragona", "MediaMarkt Almería", "MediaMarkt Gran Plaza", 
            "MediaMarkt Bahía de Cádiz", "MediaMarkt Jerez de la Frontera", "MediaMarkt Los Barrios", "MediaMarkt Córdoba", 
            "MediaMarkt Nevada", "MediaMarkt Granda - Pulianas", "MediaMarkt Huelva", "MediaMarkt Jaén", "MediaMarkt Málaga - La Cañada", 
            "MediaMarkt Mijas", "MediaMarkt Málaga", "MediaMarkt Plaza Mayor", "MediaMarkt Vélez", "MediaMarkt Alcalá de Guadaíra", 
            "MediaMarkt Lagoh", "MediaMarkt Los Arcos", "MediaMarkt San Juan de Aznalfarache", "MediaMarkt Badajoz", 
            "MediaMarkt Albacete", "MediaMarkt Alicante", "MediaMarkt Elche", "MediaMarkt Finestrat", "MediaMarkt La Zenia", 
            "MediaMarkt Castellón", "MediaMarkt Vinaròs", "MediaMarkt Cartagena", "MediaMarkt Lorca", "MediaMarkt Nueva Condomina", 
            "MediaMarkt Ronda Sur", "MediaMarkt Alfafar", "MediaMarkt Valencia - Aqua", "MediaMarkt Valencia - Colón", 
            "MediaMarkt Gandía", "MediaMarkt Puerto Sagunto", "MediaMarkt Valencia - Palacio de Congresos", "MediaMarkt Quart de Poblet", 
            "MediaMarkt - Toledo", "MediaMarkt Ciudad Real", "MediaMarkt Alcalá de Henares", "MediaMarkt Alcorcón", 
            "MediaMarkt Benlliure - Goya", "MediaMarkt Castellana", "MediaMarkt Collado Villalba", "MediaMarkt Fuenlabrada", 
            "MediaMarkt Getafe", "MediaMarkt Isazul", "MediaMarkt Leganés", "MediaMarkt Majadahonda", "MediaMarkt Plaza del Carmen", 
            "MediaMarkt Plenilunio", "MediaMarkt Rivas Vaciamadrid", "MediaMarkt Torrejón", "MediaMarkt Vaguada", "MediaMarkt Vallecas", 
            "MediaMarkt Villaverde", "MediaMarkt Talavera", "MediaMarkt Santander", "MediaMarkt Vigo", "MediaMarkt A Coruña", 
            "MediaMarkt Ferrol", "MediaMarkt Santiago de Compostela", "MediaMarkt Vitoria", "MediaMarkt Siero", "MediaMarkt Bilbondo", 
            "MediaMarkt Zubiarte", "MediaMarkt Barakaldo", "MediaMarkt Donosti", "MediaMarkt Logroño", "MediaMarkt León", 
            "MediaMarkt Lugo", "MediaMarkt Pamplona - Cordovilla", "MediaMarkt Vigo 2", "MediaMarkt Salamanca", "MediaMarkt Valladolid", 
            "MediaMarkt Vistalegre", "MediaMarkt CC Gran Casa", "MediaMarkt Puerto Venecia", "MediaMarkt Burgos", 
            "MediaMarkt Palma de Mallorca", "MediaMarkt Palma Fan", "MediaMarkt Lanzarote", "MediaMarkt Las Arenas", 
            "MediaMarkt Alisios", "MediaMarkt Telde", "MediaMarkt Tenerife", "MediaMarkt Tres de Mayo", "MediaMarkt Adeje", "MediaMarkt Melilla"
        ],
        "ECI": [
            "Central", "El Corte Inglés A Coruña", "El Corte Inglés Ademuz", "El Corte Inglés Alcalá de Henares", "El Corte Inglés Alexandre Rosselló", 
            "El Corte Inglés Alicante", "El Corte Inglés Arabial", "El Corte Inglés Albacete", "El Corte Inglés Avenida de Francia", 
            "El Corte Inglés Badajoz", "El Corte Inglés Avilés", "El Corte Inglés Bahía Málaga", "El Corte Inglés Bahía de Algeciras", 
            "El Corte Inglés Bahía de Cádiz", "El Corte Inglés Campo de Las Naciones", "El Corte Inglés Can Dragó", "El Corte Inglés Cartagena", 
            "El Corte Inglés Castellana", "El Corte Inglés Ciudad de Elche", "El Corte Inglés Conquistadores - Badajoz", "El Corte Inglés Cornellà", 
            "El Corte Inglés Costa Mijas", "El Corte Inglés Diagonal", "El Corte Inglés El Bercial", "El Corte Inglés Marbella", 
            "El Corte Inglés El Ejido", "El Corte Inglés Guadalajara", "El Corte Inglés León", "El Corte Inglés Gaia Porto", 
            "El Corte Inglés Genil", "El Corte Inglés Gijón", "El Corte Inglés Girona", "El Corte Inglés Goya", "El Corte Inglés Gran Vía - Bilbao", 
            "El Corte Inglés Huelva", "El Corte Inglés Independencia", "El Corte Inglés Jaume III", "El Corte Inglés Jaén", "El Corte Inglés Jerez", 
            "El Corte Inglés José Mesa y López", "El Corte Inglés Lisboa", "El Corte Inglés Madrid Xanadú", "El Corte Inglés Salamanca", 
            "El Corte Inglés Murcia", "El Corte Inglés Málaga", "El Corte Inglés Nervión", "El Corte Inglés Nuevo Centro", 
            "El Corte Inglés Oviedo Salesas", "El Corte Inglés Oviedo Uría", "El Corte Inglés Pamplona", "El Corte Inglés Parque Burgos", 
            "El Corte Inglés Castellón", "El Corte Inglés Pintor Sorolla-Colón", "El Corte Inglés Plaza del Duque", "El Corte Inglés Plaça de Catalunya", 
            "El Corte Inglés Pozuelo", "El Corte Inglés Preciados-Callao", "El Corte Inglés Princesa", "El Corte Inglés Puerto Venecia", 
            "El Corte Inglés Ronda de Córdoba", "El Corte Inglés Ronda de los Tejares - Cordoba", "El Corte Inglés Sabadell", "El Corte Inglés Sagasta", 
            "El Corte Inglés San José de Valderas", "El Corte Inglés San Juan De Aznalfarache", "El Corte Inglés Sanchinarro", 
            "El Corte Inglés Santander", "El Corte Inglés Santiago de Compostela", "El Corte Inglés Serrano", "El Corte Inglés Sevilla Este", 
            "El Corte Inglés Siete Palmas", "El Corte Inglés Talavera de la Reina", "El Corte Inglés Tarragona", "El Corte Inglés Tres de Mayo", 
            "El Corte Inglés Vigo", "El Corte Inglés Vista Alegre", "El Corte Inglés Vitoria", "El Corte Inglés Zorrilla - Valladolid", 
            "Supermercado El Corte Inglés A Coruña", "Supermercado El Corte Inglés Boadilla", "Supermercado El Corte Inglés Burgos", 
            "Supermercado El Corte Inglés El Escorial", "Supermercado El Corte Inglés Reyes Magos", "Supermercado El Corte Inglés Somosaguas", 
            "Supermercado El Corte Inglés de López Ibor", "Supermercado de El Corte Inglés Francesc Macià", "Supermercado de El Corte Inglés Sotogrande"
        ],
        "Carrefour": [
            "Central", "Aluche", "Hortaleza", "Las Rosas", "Los Ángeles", "Madrid Sur", "La Gavia", "Pinar de Chamartín", 
            "Conde de Peñalver", "Alcalá de Henares", "Alcobendas", "Alcorcón", "Getafe", "Leganés", "Majadahonda", 
            "Móstoles", "Pinar de las Rozas", "Rivas-Vaciamadrid", "San Fernando de Henares", "Torrejón de Ardoz", 
            "Villalba", "Toledo", "Talavera de la Reina", "Ciudad Real", "Puertollano", "Alcázar de San Juan", 
            "Albacete", "Guadalajara", "Cuenca", "Badajoz (Valdepasillas)", "Badajoz (La Granadilla)", "Mérida", 
            "Don Benito - Villanueva", "Zafra", "Cáceres", "Plasencia", "San Pablo", "Macarena", "Montequinto", 
            "Camas", "San Juan de Aznalfarache", "Dos Hermanas", "Écija", "Alameda", "Los Patios", "La Rosaleda", 
            "Rincón de la Victoria", "Mijas", "Estepona", "Vélez-Málaga", "Torremolinos", "Antequera", "Coín", 
            "Bahía (San Fernando)", "Jerez Norte", "Jerez Sur", "El Paseo (El Puerto)", "Algeciras", "La Línea", 
            "Los Barrios", "Sanlúcar", "Granada (Armilla)", "Pulianas", "Motril", "Granada (Nevada)", "La Sierra", 
            "Zahira", "Lucena", "Baena", "Almería", "Roquetas de Mar", "El Ejido", "Vícar", "Huércal-Overa", "Huelva", 
            "Cartaya", "La Palma del Condado", "Jaén", "Úbeda", "Andújar", "Atalayas", "Zaraiche", "El Tiro", 
            "Cartagena", "Paseo Alfonso XIII", "Lorca", "Águilas", "San Javier", "Yecla", "El Saler", "Campanar", 
            "Arena", "Alfafar", "Paterna (Heron City)", "Paterna (Pista de Ademuz)", "Massalfassar", "Sagunto", 
            "Alzira", "Gandía", "La Eliana", "Cullera", "Ontinyent", "Xàtiva", "Puerta de Alicante", "Gran Vía", 
            "San Juan", "Elche", "Torrevieja", "Benidorm (Finestrat)", "Dénia", "Orihuela", "Petrer", 
            "Valladolid (Parquesol)", "Valladolid (Delicias)", "Laguna de Duero", "León", "Ponferrada", 
            "Burgos (El Mirador)", "Burgos (Carretera de Logroño)", "Miranda de Ebro", "Salamanca", 
            "Salamanca (Avenida de los Agustinos)", "Palencia", "Segovia", "Zamora", "Ávila", "Soria", "Santa Pola", 
            "Alcoy", "Torrevieja (Centro)", "Castellón", "Vila-real", "Vinaròs", "A Coruña (Alfonso Molina)", 
            "A Coruña (Los Rosales)", "Santiago de Compostela", "Ferrol", "Oleiros", "Coristanco", "Vigo (Travesía)", 
            "Vigo (Gran Vía)", "Pontevedra", "Lalín", "Lugo", "Ribadeo", "Ourense", "Oviedo (Los Prados)", 
            "Lugones (Azabache)", "Gijón (La Calzada)", "Gijón (Los Fresnos)", "Avilés (Parque Astur)", "Pola de Siero", 
            "Santander (Peñacastillo)", "Santander (El Alisal)", "Torrelavega", "Erandio", "Sestao", "Abadiño", 
            "Oiartzun", "Eibar", "Vitoria (Gorbeia)", "Logroño", "Pamplona", "Tudela", "Augusta", "Actur", 
            "Puerto Venecia", "Utebo", "Huesca", "Teruel", "Barcelona - Glòries", "L'Hospitalet", "Badalona", 
            "Santa Coloma", "Barberà del Vallès", "Sant Cugat", "Terrassa", "Sabadell", "Cornellà", "El Prat", 
            "Gavà", "Cabrera de Mar", "Granollers", "Vic", "Manresa", "Igualada", "Martorell", "Parets del Vallès", 
            "Sant Fruitós de Bages", "Tarragona", "Reus", "Torredembarra", "Amposta", "Girona", "Figueres", "Olot", 
            "Lleida", "Añaza (Santa Cruz)", "Meridiano (Santa Cruz)", "Santa María del Mar", "Las Arenas (Las Palmas)", 
            "La Ballena (Las Palmas)", "Vecindario (Santa Lucía de Tirajana)"
        ],
        "Alcampo": [
            "Central", "Alcobendas", "Alcalá de Henares (La Dehesa)", "Alcorcón", "Colmenar Viejo", "Fuenlabrada (Lorea)", 
            "Getafe", "Leganés", "Majadahonda", "Torrejón de Ardoz", "Madrid - Vaguada", "Madrid - Vallecas", 
            "Madrid - Moratalaz", "Madrid - Pío XII", "Madrid - Estrellas", "Madrid - Vista Alegre", 
            "Zaragoza - Los Enlaces", "Zaragoza - Utebo", "Zaragoza - Picarral", "Zaragoza - Puerto Venecia", 
            "Huesca", "Teruel", "Sevilla", "Granada", "Motril", "Almería", "Jerez de la Frontera", "Sanlúcar de Barrameda", 
            "Algeciras", "Linares", "Marbella", "Barcelona - Diagonal Mar", "Sant Adrià de Besòs", "Sant Boi de Llobregat", 
            "Mataró", "Reus", "Alboraia", "Aldaia", "Castellón", "Alicante", "Orihuela Costa", "Vigo - Coia", 
            "Vigo - Avenida de Madrid", "A Coruña - Palavea", "Santiago de Compostela", "Ferrol", "Vilagarcía de Arousa", 
            "Lugo", "Valladolid", "Burgos", "Salamanca", "Zamora", "Gijón", "Santander", "Oiartzun", "Murcia", "Logroño", 
            "Toledo", "Cuenca", "Valdepeñas", "La Laguna", "Telde", "Marratxí"
        ],
        "MISTORES": [
            "MI ALMERIA", "MI CEUTA", "MI VIGO", "MI STORE C.C. LA GAVIA", "MI PUERTO VENECIA", "MI VALLADOLID", 
            "MI STORE CC GRAN VÍA ALICANTE", "MI STORE CC ISLAZUL", "MI STORE GRAN VÍA 2", "MI STORE MAQUINISTA", 
            "MI STORE XANADU", "MI STORE CASTELLÓN"
        ],
        "Orange": [
            "Central", "ONDALIBRE", "KIWITEL", "ISP", "ONE STORE", "ECOPLANA", "IS CELL", "TIENDAS DE LEVANTE", 
            "FREE TELECOM", "FREE TELECOM (Comerciales)", "OK CLUB", "MUNDOCOM", "MUNDOCOM (COMERCIALES)", 
            "ANEVINIP", "TELMASUR", "PROMOVIL", "CLM", "OSHOP", "Tiendas Propias", "DESPLIEGUE OT NORTE", 
            "DESPLIEGUE OT SUR", "DESPLIEGUE OT CENTRO", "DESPLIEGUE OT CATALUÑA", "DESPLIEGUE OT LEVANTE", 
            "ISGF Murcia", "FOUNDEVER Sevilla", "KONECTA Sevilla", "OEST Oviedo", "MARKTEL Valencia", 
            "Jazzplat Guadalajara", "ISGF Alicante", "TLP Salamanca", "TRANSCOM León", "MAJOREL Salamanca", 
            "TELEPERFORMANCE MEDELLÍN", "JAZZPLAT BOGOTÁ", "STREAM MOBILE - Cartes", "ATAKAM - Salamanca", 
            "ATAKAM - Valladolid", "KONECTA - Sevilla", "BEMORE - Madrid", "SERVINFORM - Torrejón de Ardoz", 
            "GSS - Badajoz", "KONECTA - Córdoba", "Foundever Sevilla negocios", "Teleperformance Salamanca negocios", 
            "BOSCH Vigo negocios", "COMVERS Sevilla negocios", "FOUNDEVER Sevilla negocios", "JCP2CALL Málaga negocios", 
            "KONECTA Sevilla negocios", "TNT Lugo negocios"
        ],
        "MásMóvil": [
            "Central", "Stream Cantabria", "Konecta Córdoba Residencial", "Konecta Córdoba Negocios", 
            "Servinform Madrid Residencial", "Konecta Sevilla", "Marktel Madrid Negocios", "Serviform Valladolid Negocios", 
            "Servinform Madrid Negocios", "PERU", "NEKXUS COLOMBIA", "KONECTA LIMA"
        ],
        "Vodafone": [
            "Central", "KONECTA Sevilla", "KONECTA Valladolid", "MAJOREL Zaragoza", "TP Ponferrada", "KONECTA Sevilla (PIBO)", 
            "KONECTA Valladolid (Cartera)", "MARKTEL Albacete", "VPLAT Madrid", "VPLAT Valladolid", "Red chain", "Bonatel", 
            "Pablo Sánchez XXI", "Climent", "Eulogio (grupo teleoperator)", "Grupo Móvil", "Servitel XXI", "Ondas System SL", 
            "New Concept / vivacom", "Mederos", "TDC SENSITIA", "Despliegue de Oferta Central"
        ],
        "Euskaltel": [
            "Central", "IBERMATICA Donostia", "LANALDEN Bilbao", "LANALDEN Derio", "XUPERA Barakaldo", "KONECTA A Coruña", 
            "GSC A Coruña", "Eulen Gijón", "OSP Oviedo", "V3 Valladolid"
        ],
        "Fnac": [
            "Central", "Fnac Callao", "Fnac Goya", "Fnac Castellana", "Fnac La Gavia", "Fnac Plaza Río", "Fnac Parquesur", 
            "Fnac Plaza Norte 2", "Fnac Gran Plaza 2", "Fnac Oasiz", "Fnac Connect Universidad Europea", "Fnac Triangle", 
            "Fnac L'Illa", "Fnac Arenas", "Fnac Glòries", "Fnac La Maquinista", "Fnac Splau", "Fnac Girona", "Fnac San Agustín", 
            "Fnac Bonaire", "Fnac Salera", "Fnac Alicante", "Fnac Nueva Condomina", "Fnac Sevilla", "Fnac Torre Sevilla", 
            "Fnac Málaga", "Fnac Marbella", "Fnac Granada", "Fnac Bilbao", "Fnac Donostia", "Fnac La Morea", 
            "Fnac Connect Pamplona", "Fnac Principado", "Fnac A Coruña", "Fnac Vigo", "Fnac Plaza España", 
            "Fnac Puerto Venecia", "Fnac Río Shopping", "Fnac Mallorca"
        ],
        "Telefónica": [
            "Central", "Plataformas Colombia", "Plataforma Atento Santander", "Plataforma Atento Barcelona", 
            "Plataforma Atento Toledo", "Plataforma Eurocen La Coruña", "Plataforma Eurocen Zaragoza", 
            "Plataforma Eurocen Málaga", "Talleres flagship Aprende", "COMMCENTER", "PHONEMOVIL", 
            "PHONEMOVIL PYMES", "JOVITEL", "CATPHONE", "JESMON", "BERMA", "MOBILEPHONE", "COMPLUTEL", "Telyco"
        ]
    };

    const dispositivosMobiles = ["Redmi 15 Series", "Redmi 15C Series", "Redmi 17 Series", "Redmi A5", "Redmi A7 Pro", "Redmi Note 15 Series", "Redmi Note 17 Series", "Xiaomi 17 series", "Xiaomi 17T Series", "Xiaomi 18 Pro Series"];
    const dispositivosNoMobiles = ["Air Fryer Series", "Aire Acondicionado", "Cámaras de Vigilancia", "Frigorífico", "Lavadora", "Redmi Buds 8 Series", "Redmi Pad 2 9.7\"", "Redmi Pad 2 Pro Series", "Redmi Pad 2 Series", "Redmi Watch 5 Series", "Redmi Watch 6 Series", "Robot Vacuum", "Scooters", "TV A 2026 Series", "TV F 2026 Series", "TV FX 2026 Series", "TV S 2026 Series", "Vacuum", "Xiaomi Band 11 Series", "Xiaomi Buds 5 Series", "Xiaomi Buds 6 Series", "Xiaomi Clip", "Xiaomi Openwear Stereo Series", "Xiaomi Pad 8 Series", "Xiaomi Watch 5 Series", "Xiaomi Watch S4 Series", "Xiaomi Watch S5 41 mm", "Xiaomi Watch S5 Series"];

    const html = `
    <div class="report-module fade-in">
        <header class="section-header page-heading">
            <span class="page-eyebrow">Actividad de formación</span>
            <h2><i data-lucide="square-pen"></i>${editData && editData.mode === 'edit' ? 'Editar reporte' : (editData && editData.mode === 'duplicate' ? 'Duplicar reporte' : 'Crear reporte')}</h2>
            <p>Registra la sesión con la información necesaria para el seguimiento del equipo.</p>
            <div id="reportDraftStatus" class="report-draft-status" aria-live="polite"><i data-lucide="cloud-check"></i><span>${editData ? 'Edición protegida' : 'Borrador automático activo'}</span></div>
        </header>

        <form id="trainingForm" class="report-form-card">
            <div id="adminArea" class="report-admin-context">
                <div class="report-admin-label"><i data-lucide="user-round-cog"></i><span>Actuando como</span></div>
                <div class="form-group">
                    <label class="form-label sr-only" for="trainer">Seleccionar trainer</label>
                    <select id="trainer" name="trainer" class="form-control">
                        <option value="${currentUser}">${currentUser}</option>
                    </select>
                </div>
            </div>

            <div class="form-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                <div class="form-group">
                    <label class="form-label" for="fecha">Fecha de formación</label>
                    <input type="date" id="fecha" name="fecha" class="form-control" required value="${editData ? editData.fecha : ''}">
                </div>

                <div class="form-group">
                    <label class="form-label" for="metodologia">Metodología</label>
                    <select id="metodologia" name="metodologia" class="form-control" required>
                        <option value="" disabled ${!editData ? 'selected' : ''}>Selecciona...</option>
                        <option value="Backoffice" ${editData && editData.metodologia === 'Backoffice' ? 'selected' : ''}>Backoffice</option>
                        <option value="Classroom" ${editData && editData.metodologia === 'Classroom' ? 'selected' : ''}>Classroom</option>
                        <option value="Evento" ${editData && editData.metodologia === 'Evento' ? 'selected' : ''}>Evento</option>
                        <option value="Hospitality" ${editData && editData.metodologia === 'Hospitality' ? 'selected' : ''}>Hospitality</option>
                        <option value="Live" ${editData && editData.metodologia === 'Live' ? 'selected' : ''}>Live</option>
                        <option value="POS" ${editData && editData.metodologia === 'POS' ? 'selected' : ''}>POS</option>
                        <option value="Reunión Interna" ${editData && editData.metodologia === 'Reunión Interna' ? 'selected' : ''}>Reunión Interna</option>
                        <option value="Training Material" ${editData && editData.metodologia === 'Training Material' ? 'selected' : ''}>Training Material</option>
                        <option value="Viaje" ${editData && editData.metodologia === 'Viaje' ? 'selected' : ''}>Viaje</option>
                        <option value="Webinar" ${editData && editData.metodologia === 'Webinar' ? 'selected' : ''}>Webinar</option>
                    </select>
                </div>

                <div class="form-group" id="wrapperCuenta">
                    <label class="form-label" for="cuenta">Cuenta *</label>
                    <select id="cuenta" name="cuenta" class="form-control" required>
                        <option value="" disabled ${!editData ? 'selected' : ''}>Selecciona la cuenta...</option>
                        <option value="Evento Xiaomi" ${editData && editData.cuenta === 'Evento Xiaomi' ? 'selected' : ''}>Evento Xiaomi</option>
                        <option value="Internal Training" ${editData && editData.cuenta === 'Internal Training' ? 'selected' : ''}>Internal Training</option>
                        <option value="MediaMarkt" ${editData && editData.cuenta === 'MediaMarkt' ? 'selected' : ''}>MediaMarkt</option>
                        <option value="ECI" ${editData && editData.cuenta === 'ECI' ? 'selected' : ''}>ECI</option>
                        <option value="Carrefour" ${editData && editData.cuenta === 'Carrefour' ? 'selected' : ''}>Carrefour</option>
                        <option value="Alcampo" ${editData && editData.cuenta === 'Alcampo' ? 'selected' : ''}>Alcampo</option>
                        <option value="Orange" ${editData && editData.cuenta === 'Orange' ? 'selected' : ''}>Orange</option>
                        <option value="Vodafone" ${editData && editData.cuenta === 'Vodafone' ? 'selected' : ''}>Vodafone</option>
                        <option value="MásMóvil" ${editData && editData.cuenta === 'MásMóvil' ? 'selected' : ''}>MásMóvil</option>
                        <option value="Euskaltel" ${editData && editData.cuenta === 'Euskaltel' ? 'selected' : ''}>Euskaltel</option>
                        <option value="Fnac" ${editData && editData.cuenta === 'Fnac' ? 'selected' : ''}>Fnac</option>
                        <option value="MISTORES" ${editData && editData.cuenta === 'MISTORES' ? 'selected' : ''}>MISTORES</option>
                        <option value="Telefónica" ${editData && editData.cuenta === 'Telefónica' ? 'selected' : ''}>Telefónica</option>
                    </select>
                </div>

                <div class="form-group" id="distWrapper" style="display: none;">
                    <label class="form-label" for="distribuidor">Distribuidor / Tienda / Plataforma</label>
                    <select id="distribuidor" name="distribuidor" class="form-control"></select>
                </div>

                <div class="form-group" id="wrapperCiudad">
                    <label class="form-label" for="ciudad">Ciudad</label>
                    <select id="ciudad" name="ciudad" class="form-control" required placeholder="Escribe o selecciona ciudad..."></select>
                </div>

                <div class="form-group" id="wrapperProvincia">
                    <label class="form-label" for="provincia">Provincia</label>
                    <select id="provincia" name="provincia" class="form-control" required>
                        <option value="" disabled ${!editData ? 'selected' : ''}>Selecciona provincia...</option>
                        <option value="COLOMBIA" ${editData && editData.provincia === 'COLOMBIA' ? 'selected' : ''}>COLOMBIA</option>
                        <option value="EUROPA" ${editData && editData.provincia === 'EUROPA' ? 'selected' : ''}>EUROPA</option>
                        <option value="PORTUGAL" ${editData && editData.provincia === 'PORTUGAL' ? 'selected' : ''}>PORTUGAL</option>
                        <optgroup label="España">
                            <option value="Álava" ${editData && editData.provincia === 'Álava' ? 'selected' : ''}>Álava</option>
                            <option value="Albacete" ${editData && editData.provincia === 'Albacete' ? 'selected' : ''}>Albacete</option>
                            <option value="Alicante" ${editData && editData.provincia === 'Alicante' ? 'selected' : ''}>Alicante</option>
                            <option value="Almería" ${editData && editData.provincia === 'Almería' ? 'selected' : ''}>Almería</option>
                            <option value="Asturias" ${editData && editData.provincia === 'Asturias' ? 'selected' : ''}>Asturias</option>
                            <option value="Ávila" ${editData && editData.provincia === 'Ávila' ? 'selected' : ''}>Ávila</option>
                            <option value="Badajoz" ${editData && editData.provincia === 'Badajoz' ? 'selected' : ''}>Badajoz</option>
                            <option value="Baleares" ${editData && editData.provincia === 'Baleares' ? 'selected' : ''}>Baleares</option>
                            <option value="Barcelona" ${editData && editData.provincia === 'Barcelona' ? 'selected' : ''}>Barcelona</option>
                            <option value="Burgos" ${editData && editData.provincia === 'Burgos' ? 'selected' : ''}>Burgos</option>
                            <option value="Cáceres" ${editData && editData.provincia === 'Cáceres' ? 'selected' : ''}>Cáceres</option>
                            <option value="Cádiz" ${editData && editData.provincia === 'Cádiz' ? 'selected' : ''}>Cádiz</option>
                            <option value="Cantabria" ${editData && editData.provincia === 'Cantabria' ? 'selected' : ''}>Cantabria</option>
                            <option value="Castellón" ${editData && editData.provincia === 'Castellón' ? 'selected' : ''}>Castellón</option>
                            <option value="Ceuta" ${editData && editData.provincia === 'Ceuta' ? 'selected' : ''}>Ceuta</option>
                            <option value="Ciudad Real" ${editData && editData.provincia === 'Ciudad Real' ? 'selected' : ''}>Ciudad Real</option>
                            <option value="Córdoba" ${editData && editData.provincia === 'Córdoba' ? 'selected' : ''}>Córdoba</option>
                            <option value="Cuenca" ${editData && editData.provincia === 'Cuenca' ? 'selected' : ''}>Cuenca</option>
                            <option value="Gerona" ${editData && editData.provincia === 'Gerona' ? 'selected' : ''}>Gerona</option>
                            <option value="Granada" ${editData && editData.provincia === 'Granada' ? 'selected' : ''}>Granada</option>
                            <option value="Guadalajara" ${editData && editData.provincia === 'Guadalajara' ? 'selected' : ''}>Guadalajara</option>
                            <option value="Guipúzcoa" ${editData && editData.provincia === 'Guipúzcoa' ? 'selected' : ''}>Guipúzcoa</option>
                            <option value="Huelva" ${editData && editData.provincia === 'Huelva' ? 'selected' : ''}>Huelva</option>
                            <option value="Huesca" ${editData && editData.provincia === 'Huesca' ? 'selected' : ''}>Huesca</option>
                            <option value="Jaén" ${editData && editData.provincia === 'Jaén' ? 'selected' : ''}>Jaén</option>
                            <option value="La Coruña" ${editData && editData.provincia === 'La Coruña' ? 'selected' : ''}>La Coruña</option>
                            <option value="La Rioja" ${editData && editData.provincia === 'La Rioja' ? 'selected' : ''}>La Rioja</option>
                            <option value="Las Palmas" ${editData && editData.provincia === 'Las Palmas' ? 'selected' : ''}>Las Palmas</option>
                            <option value="León" ${editData && editData.provincia === 'León' ? 'selected' : ''}>León</option>
                            <option value="Lérida" ${editData && editData.provincia === 'Lérida' ? 'selected' : ''}>Lérida</option>
                            <option value="Lugo" ${editData && editData.provincia === 'Lugo' ? 'selected' : ''}>Lugo</option>
                            <option value="Madrid" ${editData && editData.provincia === 'Madrid' ? 'selected' : ''}>Madrid</option>
                            <option value="Málaga" ${editData && editData.provincia === 'Málaga' ? 'selected' : ''}>Málaga</option>
                            <option value="Melilla" ${editData && editData.provincia === 'Melilla' ? 'selected' : ''}>Melilla</option>
                            <option value="Murcia" ${editData && editData.provincia === 'Murcia' ? 'selected' : ''}>Murcia</option>
                            <option value="Navarra" ${editData && editData.provincia === 'Navarra' ? 'selected' : ''}>Navarra</option>
                            <option value="Orense" ${editData && editData.provincia === 'Orense' ? 'selected' : ''}>Orense</option>
                            <option value="Palencia" ${editData && editData.provincia === 'Palencia' ? 'selected' : ''}>Palencia</option>
                            <option value="Pontevedra" ${editData && editData.provincia === 'Pontevedra' ? 'selected' : ''}>Pontevedra</option>
                            <option value="Salamanca" ${editData && editData.provincia === 'Salamanca' ? 'selected' : ''}>Salamanca</option>
                            <option value="Santa Cruz de Tenerife" ${editData && editData.provincia === 'Santa Cruz de Tenerife' ? 'selected' : ''}>Santa Cruz de Tenerife</option>
                            <option value="Segovia" ${editData && editData.provincia === 'Segovia' ? 'selected' : ''}>Segovia</option>
                            <option value="Sevilla" ${editData && editData.provincia === 'Sevilla' ? 'selected' : ''}>Sevilla</option>
                            <option value="Soria" ${editData && editData.provincia === 'Soria' ? 'selected' : ''}>Soria</option>
                            <option value="Tarragona" ${editData && editData.provincia === 'Tarragona' ? 'selected' : ''}>Tarragona</option>
                            <option value="Teruel" ${editData && editData.provincia === 'Teruel' ? 'selected' : ''}>Teruel</option>
                            <option value="Toledo" ${editData && editData.provincia === 'Toledo' ? 'selected' : ''}>Toledo</option>
                            <option value="Valencia" ${editData && editData.provincia === 'Valencia' ? 'selected' : ''}>Valencia</option>
                            <option value="Valladolid" ${editData && editData.provincia === 'Valladolid' ? 'selected' : ''}>Valladolid</option>
                            <option value="Vizcaya" ${editData && editData.provincia === 'Vizcaya' ? 'selected' : ''}>Vizcaya</option>
                            <option value="Zamora" ${editData && editData.provincia === 'Zamora' ? 'selected' : ''}>Zamora</option>
                            <option value="Zaragoza" ${editData && editData.provincia === 'Zaragoza' ? 'selected' : ''}>Zaragoza</option>
                        </optgroup>
                    </select>
                </div>
            </div>

            <hr style="border: 0; border-top: 1px solid var(--border-main); margin: 2rem 0;">

            <div class="form-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                <div class="form-group" id="wrapperContenidos">
                    <label class="form-label" for="contenidos">Contenidos</label>
                    <select id="contenidos" name="contenidos" class="form-control" required>
                        <option value="" disabled ${!editData ? 'selected' : ''}>Selecciona contenido...</option>
                        <option value="Launch" ${editData && editData.contenidos === 'Launch' ? 'selected' : ''}>Launch</option>
                        <option value="On boarding" ${editData && editData.contenidos === 'On boarding' ? 'selected' : ''}>On boarding</option>
                        <option value="Reforce" ${editData && editData.contenidos === 'Reforce' ? 'selected' : ''}>Reforce</option>
                        <option value="Refresh" ${editData && editData.contenidos === 'Refresh' ? 'selected' : ''}>Refresh</option>
                    </select>
                </div>

                <div class="form-group" id="wrapperPerfil">
                    <label class="form-label" for="perfil">Perfil de asistentes</label>
                    <select id="perfil" name="perfil" class="form-control" required>
                        <option value="" disabled ${!editData ? 'selected' : ''}>Selecciona perfil...</option>
                        <option value="Cliente Final" ${editData && editData.perfil === 'Cliente Final' ? 'selected' : ''}>Cliente Final</option>
                        <option value="Interno" ${editData && editData.perfil === 'Interno' ? 'selected' : ''}>Interno</option>
                        <option value="Prensa" ${editData && editData.perfil === 'Prensa' ? 'selected' : ''}>Prensa</option>
                        <option value="Promotor" ${editData && editData.perfil === 'Promotor' ? 'selected' : ''}>Promotor</option>
                        <option value="Teleoperador" ${editData && editData.perfil === 'Teleoperador' ? 'selected' : ''}>Teleoperador</option>
                        <option value="Trainer" ${editData && editData.perfil === 'Trainer' ? 'selected' : ''}>Trainer</option>
                        <option value="Vendedor" ${editData && editData.perfil === 'Vendedor' ? 'selected' : ''}>Vendedor</option>
                    </select>
                </div>
            </div>

            <div class="form-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 1.5rem; margin-top: 1.5rem;">
                <div class="form-group" id="wrapperSesiones">
                    <label class="form-label" for="sesiones">Nº Sesiones</label>
                    <input type="number" id="sesiones" name="sesiones" class="form-control" min="0" required value="${editData ? editData.sesiones : ''}" placeholder="0">
                </div>
                <div class="form-group" id="wrapperAlumnos">
                    <label class="form-label" for="alumnos">Nº Personas</label>
                    <input type="number" id="alumnos" name="alumnos" class="form-control" min="0" required value="${editData ? editData.alumnos : ''}" placeholder="0">
                </div>
                <div class="form-group" id="wrapperTiendas">
                    <label class="form-label" for="tiendas">Nº de Tiendas</label>
                    <input type="number" id="tiendas" name="tiendas" class="form-control" min="0" required value="${editData ? editData.tiendas : ''}" placeholder="0">
                </div>
                <div class="form-group" id="wrapperHoras">
                    <label class="form-label" for="duracion">Duración (Horas)</label>
                    <input type="number" id="duracion" name="duracion" class="form-control" step="0.25" min="0" required value="${editData ? editData.duracion : ''}" placeholder="0.00">
                </div>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <label class="form-label">Dispositivos Xiaomi</label>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <select id="dispositivos" name="dispositivos" multiple placeholder="Móviles..."></select>
                    <select id="dispositivos_no_movil" name="dispositivos_no_movil" multiple placeholder="Ecosistema..."></select>
                </div>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <label class="form-label" for="comentarios">Comentarios / Observaciones</label>
                <textarea id="comentarios" name="comentarios" class="form-control" style="min-height: 100px; resize: vertical;" placeholder="Cualquier detalle relevante...">${editData ? editData.comentarios : ''}</textarea>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <label class="form-label" id="photoLabel">Fotos (0/20)</label>
                <div id="photoStatusAlert" style="display: none; margin-bottom: 12px; padding: 10px 14px; border-radius: var(--border-radius-md); font-size: 0.85rem; transition: all 0.2s ease;"></div>
                <div id="photoContainer" style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 10px;">
                    <button type="button" class="photo-upload-box" id="photoTrigger" aria-describedby="photoHelp" style="width: 100px; height: 100px; border: 2px dashed var(--border-main); border-radius: var(--border-radius-md); display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; background:var(--bg-main);">
                        <i data-lucide="camera" style="width: 32px; height: 32px; color: var(--text-muted);"></i>
                        <span style="font-size: 0.65rem; color: var(--text-muted); margin-top: 8px; font-weight: 700;">Añadir</span>
                    </button>
                </div>
                <input type="file" id="photoInput" style="display: none;" accept="image/*,.heic,.heif" multiple>
                <input type="hidden" id="photoData" name="photoData">
                <p id="photoHelp" style="font-size:0.7rem; color:var(--text-muted); margin-top:10px;">Hasta 20 fotos (máx. 30 MB por foto). Se optimizan automáticamente y se verifica su preparación antes del envío.</p>
            </div>

            <div style="margin-top: 3rem; display: flex; gap: 15px;">
                ${editData ? '<button type="button" id="btnCancel" class="btn-outline" style="flex:1; height: 55px; font-size: 1.1rem;">Cancelar</button>' : ''}
                <button type="submit" id="btnSubmit" class="btn-primary" style="flex: 2; height: 55px; font-size: 1.1rem; font-weight: 700;">
                    <i data-lucide="send" style="width: 20px;"></i> ${editData && editData.mode === 'edit' ? 'Guardar Cambios' : 'Enviar Reporte'}
                </button>
            </div>
        </form>
    </div>
    `;

    container.innerHTML = html;
    if (typeof lucide !== 'undefined') lucide.createIcons();
    if(!editData) document.getElementById('fecha').valueAsDate = new Date();

    if (role === 'Admin') {
        document.getElementById('adminArea').style.display = 'block';
        api.getUsersList().then(res => {
            if(res.status === 'success') {
                const s = document.getElementById('trainer'); 
                if(s) {
                    s.replaceChildren();
                    res.data.forEach(u => {
                        const option = document.createElement('option');
                        option.value = u.user || u;
                        option.textContent = u.name || u;
                        s.appendChild(option);
                    });
                    s.value = editData ? editData.trainer : currentUser;
                }
            }
        });
    }

    let tsTienda = null;
    const tsCue = new TomSelect("#cuenta", { 
        placeholder: "Busca cuenta...",
        sortField: { field: "text", direction: "asc" },
        maxOptions: null
    });

    const updateTiendas = (val) => {
        const dw = document.getElementById('distWrapper'), ds = document.getElementById('distribuidor');
        if(!dw || !ds) return;

        if (val === "Internal Training") {
            dw.style.display = 'none';
            if(tsTienda) { tsTienda.destroy(); tsTienda = null; }
            ds.innerHTML = "";
            return;
        }

        if(tsTienda) { tsTienda.destroy(); tsTienda = null; }
        
        if(distribuidores[val]) {
            dw.style.display = 'block'; 
            ds.innerHTML = '<option value="">Busca o selecciona tienda...</option>';
            distribuidores[val].forEach(d => {
                const opt = document.createElement('option');
                opt.value = d; opt.innerText = d;
                ds.appendChild(opt);
            });
            
            tsTienda = new TomSelect("#distribuidor", {
                create: true,
                placeholder: "Escribe para buscar o añadir...",
                sortField: { field: "text", direction: "asc" },
                maxOptions: null
            });

            if(editData && editData.distribuidor) {
                const cleanVal = editData.distribuidor.replace(/^\+ /, '');
                // Si no está en la lista (custom store), lo añadimos como opción primero para que TomSelect lo reconozca
                if (!distribuidores[val].includes(cleanVal)) {
                    tsTienda.addOption({ value: cleanVal, text: cleanVal });
                }
                tsTienda.setValue(cleanVal);
            }
        } else {
            dw.style.display = 'none';
        }
    };

    tsCue.on('change', (val) => updateTiendas(val));

    const tsCiudad = new TomSelect("#ciudad", { 
        create: true, 
        placeholder: "Escribe..."
    });
    const tsM = new TomSelect("#dispositivos", { 
        plugins: ['remove_button'], 
        create: true, 
        placeholder: "Móviles...",
        onItemAdd: function() {
            this.setTextboxValue('');
            this.refreshOptions();
        }
    });
    dispositivosMobiles.forEach(d => tsM.addOption({value:d, text:d}));
    const tsNM = new TomSelect("#dispositivos_no_movil", { 
        plugins: ['remove_button'], 
        create: true, 
        placeholder: "Ecosistema...",
        onItemAdd: function() {
            this.setTextboxValue('');
            this.refreshOptions();
        }
    });
    dispositivosNoMobiles.forEach(d => tsNM.addOption({value:d, text:d}));

    api.getCitiesList().then(res => { 
        if(res.status==='success' && tsCiudad) {
             res.data.forEach(c => tsCiudad.addOption({value:c, text:c}));
             if(editData) tsCiudad.setValue(editData.ciudad);
        }
    });

    const met = document.getElementById('metodologia'), con = document.getElementById('contenidos'), 
          per = document.getElementById('perfil');
    
    met.onchange = () => {
        const triggers = ["Backoffice", "Training Material", "Viaje", "Reunión Interna"], isBlock = triggers.includes(met.value);
        if(tsCue) { isBlock ? tsCue.disable() : tsCue.enable(); }
        if(con) { con.disabled = isBlock; con.required = !isBlock; }
        if(per) { per.disabled = isBlock; per.required = !isBlock; }
        ['wrapperCuenta', 'wrapperContenidos', 'wrapperPerfil'].forEach(id => {
            const el = document.getElementById(id);
            if(el) el.style.opacity = isBlock ? "0.4" : "1";
        });
        if(isBlock && !isLoadingEdit) { 
            if(tsCue) tsCue.clear();
            if(con) con.value = ""; if(per) per.value = "";
            document.getElementById('distWrapper').style.display='none'; 
        }
    };

    if(editData) {
        if(editData.metodologia) met.onchange();
        if(editData.cuenta) {
            tsCue.setValue(editData.cuenta);
            updateTiendas(editData.cuenta);
        }
        if(editData.dispositivos) tsM.setValue(editData.dispositivos.split(',').map(s=>s.trim()));
        if(editData.dispositivos_no_movil) tsNM.setValue(editData.dispositivos_no_movil.split(',').map(s=>s.trim()));
    }

    // --- NUEVO COMPRESOR DE IMÁGENES PARA MÓVIL ---
    async function compressImage(file, maxWidth = 960, quality = 0.60) {
        let fileToProcess = file;
        
        // Soporte para HEIC/HEIF (Apple)
        if (file.type === "image/heic" || file.type === "image/heif" || file.name.toLowerCase().endsWith(".heic") || file.name.toLowerCase().endsWith(".heif")) {
            try {
                if (typeof heic2any === 'undefined') {
                    await window.loadScriptOnce('https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js', 'heic2any');
                }
                if (typeof heic2any !== 'undefined') {
                    const blob = await heic2any({
                        blob: file,
                        toType: "image/jpeg",
                        quality: 0.7
                    });
                    fileToProcess = Array.isArray(blob) ? blob[0] : blob;
                }
            } catch (e) {
                console.error("Error al convertir HEIC:", e);
                // Si falla heic2any, se intentará cargar directamente como imagen en canvas
            }
        }

        if (typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined' && typeof createImageBitmap === 'function') {
            try {
                return await new Promise((resolve, reject) => {
                    const worker = new Worker(new URL('src/services/photo-worker.js', document.baseURI));
                    const timeout = setTimeout(() => {
                        worker.terminate();
                        reject(new Error('La compresión ha tardado demasiado.'));
                    }, 30000);
                    const finish = () => { clearTimeout(timeout); worker.terminate(); };
                    worker.onmessage = ({ data }) => {
                        finish();
                        if (data.error) reject(new Error(data.error));
                        else resolve(data.base64);
                    };
                    worker.onerror = () => { finish(); reject(new Error('Compresor no disponible.')); };
                    worker.postMessage({ file: fileToProcess, maxWidth, quality });
                });
            } catch (error) {
                // Fall back for browsers or formats without worker support.
            }
        }
        return new Promise((resolve, reject) => {
            const img = new Image();
            const url = URL.createObjectURL(fileToProcess);
            img.onload = () => {
                URL.revokeObjectURL(url);
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height = Math.round(height * (maxWidth / width));
                        width = maxWidth;
                    }
                } else {
                    if (height > maxWidth) {
                        width = Math.round(width * (maxWidth / height));
                        height = maxWidth;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = (err) => {
                URL.revokeObjectURL(url);
                reject(new Error("Error al cargar la imagen para compresión"));
            };
            img.src = url;
        });
    }

    const photoInput = document.getElementById('photoInput');
    const photoTrigger = document.getElementById('photoTrigger');
    const photoContainer = document.getElementById('photoContainer');
    let photosArray = [];
    let processingPhotos = false;
    let existingPhotos = [];

    function formatBytes(bytes) {
        if (!bytes || bytes <= 0) return '0 KB';
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    function updatePhotoStatusAlert(processingMsg = null) {
        const alertBox = document.getElementById('photoStatusAlert');
        const submitBtn = document.getElementById('btnSubmit');
        if (!alertBox) return;

        if (processingMsg) {
            alertBox.style.display = 'flex';
            alertBox.style.alignItems = 'center';
            alertBox.style.gap = '10px';
            alertBox.style.background = 'rgba(255, 103, 0, 0.08)';
            alertBox.style.border = '1px solid var(--xiaomi-orange)';
            alertBox.style.color = 'var(--text-main)';
            alertBox.innerHTML = `
                <div class="loader" style="width: 18px; height: 18px; border-width: 2px; border-color: var(--xiaomi-orange) transparent transparent; flex-shrink: 0;"></div>
                <span style="font-size: 0.82rem;"><strong>Procesando imágenes:</strong> ${escapeHTML(processingMsg)}</span>
            `;
            return;
        }

        const totalBytes = photosArray.reduce((acc, p) => acc + (p.byteSize || Math.ceil((p.base64Data.length * 3) / 4)), 0);
        const countNew = photosArray.length;
        const countOld = existingPhotos.length;

        if (countNew > 0) {
            alertBox.style.display = 'flex';
            alertBox.style.alignItems = 'center';
            alertBox.style.gap = '10px';
            alertBox.style.background = 'rgba(16, 185, 129, 0.08)';
            alertBox.style.border = '1px solid #10b981';
            alertBox.style.color = 'var(--text-main)';
            alertBox.innerHTML = `
                <i data-lucide="check-circle-2" style="width: 20px; height: 20px; color: #10b981; flex-shrink: 0;"></i>
                <div style="flex: 1; font-size: 0.8rem; line-height: 1.35;">
                    <div style="font-weight: 700; color: #059669; font-size: 0.85rem;">
                        ✓ ${countNew} foto${countNew > 1 ? 's' : ''} cargada${countNew > 1 ? 's' : ''} y lista${countNew > 1 ? 's' : ''} para subir (${formatBytes(totalBytes)})
                    </div>
                    <div style="color: var(--text-muted); font-size: 0.75rem; margin-top: 2px;">
                        Las imágenes han sido optimizadas en memoria. Se adjuntarán y subirán a Drive al pulsar el botón de abajo.
                        ${countOld > 0 ? ` · <span style="color:#2563eb; font-weight:600;">+ ${countOld} foto${countOld > 1 ? 's' : ''} ya guardada${countOld > 1 ? 's' : ''} en Drive</span>` : ''}
                    </div>
                </div>
            `;
        } else if (countOld > 0) {
            alertBox.style.display = 'flex';
            alertBox.style.alignItems = 'center';
            alertBox.style.gap = '10px';
            alertBox.style.background = 'rgba(59, 130, 246, 0.08)';
            alertBox.style.border = '1px solid #3b82f6';
            alertBox.style.color = 'var(--text-main)';
            alertBox.innerHTML = `
                <i data-lucide="cloud" style="width: 20px; height: 20px; color: #3b82f6; flex-shrink: 0;"></i>
                <span style="font-size: 0.8rem; color: #2563eb;"><strong>${countOld} foto${countOld > 1 ? 's' : ''}</strong> guardada${countOld > 1 ? 's' : ''} previamente en Google Drive para este reporte.</span>
            `;
        } else {
            alertBox.style.display = 'none';
            alertBox.innerHTML = '';
        }

        if (submitBtn && !submitBtn.disabled) {
            const btnBaseText = editData && editData.mode === 'edit' ? 'Guardar Cambios' : 'Enviar Reporte';
            const photosBadge = countNew > 0 ? ` (${countNew} foto${countNew > 1 ? 's' : ''} lista${countNew > 1 ? 's' : ''})` : '';
            submitBtn.innerHTML = `<i data-lucide="send" style="width: 20px;"></i> ${btnBaseText}${photosBadge}`;
        }
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    if (editData && editData.photoLinks) {
        existingPhotos = editData.photoLinks.split(/[\n,]+/).map(s => s.trim()).filter(s => s.startsWith('http'));
        setTimeout(renderPhotos, 100);
    }

    if(photoTrigger) photoTrigger.onclick = () => photoInput.click();

    photoInput.onchange = async (e) => {
        if (processingPhotos) return;
        const files = Array.from(e.target.files || []);
        if (!files.length) return;

        if(photosArray.length + existingPhotos.length + files.length > 20) { 
            showToast("Límite de fotos", "Puedes adjuntar un máximo de 20 fotos por reporte."); 
            return; 
        }
        const oversized = files.find(file => file.size > 30 * 1024 * 1024);
        if (oversized) {
            showToast("Foto demasiado grande", `“${oversized.name}” supera 30 MB. Reduce el tamaño antes de subirla.`);
            photoInput.value = "";
            return;
        }
        
        processingPhotos = true;
        photoInput.disabled = true;
        photoTrigger?.setAttribute('aria-busy', 'true');
        if(photoTrigger) photoTrigger.innerHTML = '<div class="loader" style="width:20px;height:20px;border-width:2px;border-color:var(--xiaomi-orange) transparent transparent;"></div>';
        updatePhotoStatusAlert(`Preparando ${files.length} foto(s)…`);
        
        let addedCount = 0;
        for (let i = 0; i < files.length; i++) {
            try {
                updatePhotoStatusAlert(`Optimizando foto ${i + 1} de ${files.length} (“${files[i].name}”)…`);
                const compressedBase64 = await compressImage(files[i]);
                if (!form.isConnected) break;
                const estimatedBytes = Math.ceil((compressedBase64.length * 3) / 4);
                const currentBytes = photosArray.reduce((total, photo) => total + (photo.byteSize || Math.ceil((photo.base64Data.length * 3) / 4)), 0);
                if (estimatedBytes > 1.8 * 1024 * 1024 || currentBytes + estimatedBytes > 12 * 1024 * 1024) {
                    throw new Error("La imagen comprimida supera el límite seguro de envío.");
                }
                photosArray.push({
                    name: files[i].name,
                    mimeType: 'image/jpeg',
                    base64Data: compressedBase64,
                    byteSize: estimatedBytes,
                    formattedSize: formatBytes(estimatedBytes)
                });
                addedCount++;
                renderPhotos(); 
            } catch (err) {
                console.error("Error comprimiendo foto:", err);
                if (typeof showToast === 'function') showToast("Foto no añadida", `${files[i].name}: ${err.message}`);
            }
        }
        
        processingPhotos = false;
        photoInput.disabled = false;
        photoTrigger?.removeAttribute('aria-busy');
        if(photoTrigger) photoTrigger.innerHTML = '<i data-lucide="camera" style="width: 32px; height: 32px; color: var(--text-muted);"></i><span style="font-size: 0.65rem; color: var(--text-muted); margin-top: 8px; font-weight: 700;">Añadir</span>';
        if (typeof lucide !== 'undefined') lucide.createIcons();
        
        photoInput.value = "";
        updatePhotoStatusAlert();
        if (addedCount > 0 && typeof showToast === 'function') {
            showToast("Fotos preparadas", `${addedCount} foto(s) procesada(s) con éxito y lista(s) para enviar.`);
        }
    };

    function renderPhotos() {
        const boxes = photoContainer.querySelectorAll('.photo-thumb-v9');
        boxes.forEach(b => b.remove());
        
        const total = photosArray.length + existingPhotos.length;
        const label = document.getElementById('photoLabel');
        if(label) label.innerText = `Fotos (${total}/20)`;

        // Viejas (existingPhotos) - Borde azul para distinguir
        existingPhotos.forEach((p, idx) => {
            const div = document.createElement('div');
            div.className = 'photo-thumb-v9 fade-in';
            const idMatch = p.match(/id=([^&]+)/) || p.match(/\/d\/([^/]+)/);
            const fileId = idMatch ? idMatch[1] : '';
            const thumb = fileId ? `https://drive.google.com/thumbnail?id=${fileId}&sz=w300` : p;
            div.style.cssText = `width: 100px; height: 100px; border-radius: var(--border-radius-md); background: url(${thumb}) center/cover; position: relative; border: 2px solid #3b82f6; cursor:pointer; overflow: hidden;`;
            div.title = "Foto guardada en Drive · Clic para abrir";
            div.onclick = () => {
                const safeUrl = window.safeExternalUrl ? window.safeExternalUrl(p) : '';
                if (safeUrl) {
                    const opened = window.open(safeUrl, '_blank', 'noopener,noreferrer');
                    if (opened) opened.opener = null;
                }
            };
            div.innerHTML = `
                <button type="button" aria-label="Eliminar foto" style="position: absolute; top: 4px; right: 4px; background: rgba(239, 68, 68, 0.9); color: white; border: none; border-radius: 50%; width: 22px; height: 22px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; z-index:10; box-shadow: 0 1px 3px rgba(0,0,0,0.4);">×</button>
                <div style="position: absolute; bottom: 3px; left: 3px; right: 3px; background: rgba(59, 130, 246, 0.92); color: white; font-size: 0.6rem; font-weight: 700; border-radius: 4px; padding: 2px 4px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 3px; pointer-events: none; box-shadow: 0 1px 2px rgba(0,0,0,0.3);"><i data-lucide="cloud" style="width: 10px; height: 10px;"></i> Guardada</div>
            `;
            div.querySelector('button').onclick = (e) => { e.stopPropagation(); existingPhotos.splice(idx, 1); renderPhotos(); };
            photoContainer.insertBefore(div, photoTrigger);
        });

        // Nuevas (photosArray) - Borde naranja
        photosArray.forEach((p, idx) => {
            const div = document.createElement('div');
            div.className = 'photo-thumb-v9 fade-in';
            div.style.cssText = `width: 100px; height: 100px; border-radius: var(--border-radius-md); background: url(${p.base64Data}) center/cover; position: relative; border: 2px solid var(--xiaomi-orange); overflow: hidden;`;
            div.title = `${p.name} · ${p.formattedSize || ''} · Lista para subir`;
            div.innerHTML = `
                <button type="button" aria-label="Eliminar foto" style="position: absolute; top: 4px; right: 4px; background: rgba(239, 68, 68, 0.9); color: white; border: none; border-radius: 50%; width: 22px; height: 22px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; z-index:10; box-shadow: 0 1px 3px rgba(0,0,0,0.4);">×</button>
                <div style="position: absolute; bottom: 3px; left: 3px; right: 3px; background: rgba(16, 185, 129, 0.95); color: white; font-size: 0.6rem; font-weight: 700; border-radius: 4px; padding: 2px 4px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 3px; pointer-events: none; box-shadow: 0 1px 2px rgba(0,0,0,0.3);"><i data-lucide="check" style="width: 10px; height: 10px;"></i> Lista</div>
            `;
            div.querySelector('button').onclick = (e) => { e.stopPropagation(); photosArray.splice(idx, 1); renderPhotos(); };
            photoContainer.insertBefore(div, photoTrigger);
        });
        
        if(photoTrigger) photoTrigger.style.display = total >= 20 ? 'none' : 'flex';
        updatePhotoStatusAlert();
    }

    const form = document.getElementById('trainingForm');
    const draftKey = `xiaomiReportDraft:${currentUser}`;
    const draftStatus = document.getElementById('reportDraftStatus');
    let draftTimer = null;
    let reportDirty = false;

    const setDraftStatus = text => {
        if (draftStatus) draftStatus.querySelector('span').textContent = text;
    };
    const collectDraft = () => {
        const values = {};
        Array.from(form.elements).forEach(field => {
            if (!field.name || field.type === 'file' || field.type === 'submit' || field.name === 'trainer') return;
            values[field.name] = field.multiple
                ? Array.from(field.selectedOptions || []).map(option => option.value)
                : field.value;
        });
        return { values, savedAt: Date.now() };
    };
    const saveDraft = () => {
        if (editData) return;
        try {
            localStorage.setItem(draftKey, JSON.stringify(collectDraft()));
            setDraftStatus(`Borrador guardado · ${new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`);
        } catch (error) {
            setDraftStatus('No se pudo guardar el borrador en este dispositivo');
        }
    };
    const scheduleDraft = () => {
        reportDirty = true;
        if (editData) return;
        setDraftStatus('Guardando borrador…');
        clearTimeout(draftTimer);
        draftTimer = setTimeout(saveDraft, 500);
    };

    form.addEventListener('input', scheduleDraft);
    form.addEventListener('change', scheduleDraft);

    if (!editData) {
        try {
            const draft = JSON.parse(localStorage.getItem(draftKey) || 'null');
            if (draft?.values) {
                Object.entries(draft.values).forEach(([name, value]) => {
                    const field = form.elements.namedItem(name);
                    if (!field) return;
                    const nextValue = Array.isArray(value) ? value : String(value ?? '');
                    if (field.tomselect) field.tomselect.setValue(nextValue, true);
                    else field.value = nextValue;
                    field.dispatchEvent(new Event('change', { bubbles: true }));
                });
                setDraftStatus(`Borrador recuperado · ${new Date(draft.savedAt).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })}`);
            }
        } catch (error) {
            localStorage.removeItem(draftKey);
        }
    }

    if (window._reportBeforeUnload) window.removeEventListener('beforeunload', window._reportBeforeUnload);
    window._reportBeforeUnload = event => {
        if (!reportDirty) return;
        event.preventDefault();
        event.returnValue = '';
    };
    window.addEventListener('beforeunload', window._reportBeforeUnload);

    form.onsubmit = async (e) => {
        e.preventDefault();
        if (processingPhotos) {
            showToast('Preparando fotos', 'Espera a que termine la preparación antes de enviar.');
            return;
        }
        const btn = document.getElementById('btnSubmit');
        btn.disabled = true; btn.innerHTML = '<div class="loader" style="width:20px; height:20px; border-width:2px;"></div> Enviando...';

        const fd = new FormData(form);
        const data = Object.fromEntries(fd.entries());
        
        // Si la cuenta est deshabilitada (ej: Viaje, Backoffice), le asignamos N/A para que pase la validacin del backend
        if (!data.cuenta) data.cuenta = "N/A";

        data.trainer = (role === 'Admin') ? (document.getElementById('trainer').value || currentUser) : currentUser;
        data.existingPhotos = existingPhotos.join('\n');
        data.dispositivos = tsM.getValue().join(', ');
        data.dispositivos_no_movil = tsNM.getValue().join(', ');
        
        if (data.cuenta === "Internal Training") data.distribuidor = "";

        // Feedback de progreso
        if (photosArray.length > 0) {
            btn.innerHTML = `<div class="loader" style="width:20px; height:20px; border-width:2px;"></div> Enviando reporte y subiendo ${photosArray.length} fotos...`;
        } else {
            btn.innerHTML = '<div class="loader" style="width:20px; height:20px; border-width:2px;"></div> Enviando reporte...';
        }

        // Formateo exacto de las fotos para el backend V5.0
        const formattedPhotos = photosArray.map((photoObj, index) => ({
            base64Data: photoObj.base64Data, // Extraemos solo el texto base64
            name: photoObj.name || `foto_${index}.jpg`,
            mimeType: photoObj.mimeType || 'image/jpeg'
        }));

        try {
            const res = editData && editData.mode === 'edit'
                ? await api.updateReport({ data: data, rowIdx: editData.rowIdx, photos: formattedPhotos })
                : await api.saveReport(data, formattedPhotos);

            if(res.status === 'success') {
                reportDirty = false;
                localStorage.removeItem(draftKey);
                window.removeEventListener('beforeunload', window._reportBeforeUnload);
                showToast("¡Éxito!", (editData && editData.mode === 'edit') ? "Reporte actualizado." : "Reporte enviado correctamente.");
                navigate('#dashboard');
            } else {
                showToast("No se pudo guardar", res.message || "Revisa los datos e inténtalo de nuevo.");
                btn.disabled = false;
                updatePhotoStatusAlert();
            }
        } catch(err) {
            showToast("Error de conexión", "No se pudo enviar el reporte. Comprueba la conexión e inténtalo de nuevo.");
            btn.disabled = false;
            updatePhotoStatusAlert();
        }
    };

    if(editData && document.getElementById('btnCancel')) {
        document.getElementById('btnCancel').onclick = () => navigate('#dashboard');
    }
}
window.renderReport = renderReport;
